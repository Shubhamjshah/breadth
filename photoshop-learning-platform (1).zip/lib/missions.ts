// Mission definitions and validation logic
export interface MissionDefinition {
  id: string
  title: string
  description: string
  type: "daily" | "weekly" | "challenge"
  category: "tools" | "techniques" | "creative" | "speed"
  difficulty: "beginner" | "intermediate" | "advanced"
  xpReward: number
  estimatedMinutes: number
  requirements: MissionRequirement
  validation: (state: any, actions: any[]) => { completed: boolean; progress: number; maxProgress: number }
  instructions: MissionStep[]
}

export interface MissionRequirement {
  type: string
  target?: string
  count?: number
  timeLimit?: number
  accuracy?: number
  [key: string]: any
}

export interface MissionStep {
  id: string
  title: string
  instruction: string
  target?: string
  validation?: (state: any) => boolean
}

export const missionDefinitions: MissionDefinition[] = [
  {
    id: "move-tool-mastery",
    title: "Move Tool Mastery",
    description: "Learn to use the Move Tool by repositioning 3 different layers",
    type: "daily",
    category: "tools",
    difficulty: "beginner",
    xpReward: 50,
    estimatedMinutes: 10,
    requirements: {
      type: "move_layers",
      count: 3,
    },
    validation: (state, actions) => {
      const moveActions = actions.filter((a) => a.type === "move_layer")
      const uniqueLayers = new Set(moveActions.map((a) => a.layerId))
      return {
        completed: uniqueLayers.size >= 3,
        progress: uniqueLayers.size,
        maxProgress: 3,
      }
    },
    instructions: [
      {
        id: "step1",
        title: "Select Move Tool",
        instruction: "Click on the Move Tool in the toolbar (arrow icon)",
        target: "move-tool",
        validation: (state) => state.selectedTool === "move",
      },
      {
        id: "step2",
        title: "Move First Layer",
        instruction: "Click and drag the first layer to a new position",
        target: "layer1",
      },
      {
        id: "step3",
        title: "Move Second Layer",
        instruction: "Select and move the second layer",
        target: "layer2",
      },
      {
        id: "step4",
        title: "Move Third Layer",
        instruction: "Select and move the third layer to complete the mission",
        target: "layer3",
      },
    ],
  },
  {
    id: "layer-organization",
    title: "Layer Organization",
    description: "Create 5 new layers and organize them with proper names",
    type: "daily",
    category: "techniques",
    difficulty: "beginner",
    xpReward: 75,
    estimatedMinutes: 15,
    requirements: {
      type: "create_layers",
      count: 5,
      named: true,
    },
    validation: (state, actions) => {
      const createActions = actions.filter((a) => a.type === "create_layer")
      const namedLayers = createActions.filter((a) => a.name && a.name !== "Layer 1")
      return {
        completed: namedLayers.length >= 5,
        progress: namedLayers.length,
        maxProgress: 5,
      }
    },
    instructions: [
      {
        id: "step1",
        title: "Create New Layer",
        instruction: "Click the 'Add Layer' button in the Layers panel",
        target: "add-layer-button",
      },
      {
        id: "step2",
        title: "Name Your Layer",
        instruction: "Give your layer a descriptive name before creating it",
        target: "layer-name-input",
      },
      {
        id: "step3",
        title: "Repeat Process",
        instruction: "Create 4 more layers with unique names",
      },
    ],
  },
  {
    id: "brush-precision",
    title: "Brush Precision Challenge",
    description: "Use the Brush Tool to paint within specific areas without going outside the lines",
    type: "challenge",
    category: "tools",
    difficulty: "intermediate",
    xpReward: 100,
    estimatedMinutes: 20,
    requirements: {
      type: "brush_accuracy",
      accuracy: 85,
      strokes: 10,
    },
    validation: (state, actions) => {
      const brushActions = actions.filter((a) => a.type === "brush_stroke")
      const accurateStrokes = brushActions.filter((a) => a.accuracy >= 85)
      return {
        completed: accurateStrokes.length >= 10,
        progress: accurateStrokes.length,
        maxProgress: 10,
      }
    },
    instructions: [
      {
        id: "step1",
        title: "Select Brush Tool",
        instruction: "Choose the Brush Tool from the toolbar",
        target: "brush-tool",
      },
      {
        id: "step2",
        title: "Adjust Brush Size",
        instruction: "Set your brush size to 10px for precision work",
        target: "brush-size",
      },
      {
        id: "step3",
        title: "Paint Carefully",
        instruction: "Paint within the highlighted areas without crossing the boundaries",
        target: "paint-area",
      },
    ],
  },
  {
    id: "speed-selection",
    title: "Speed Selection",
    description: "Make 5 accurate selections in under 2 minutes using different selection tools",
    type: "weekly",
    category: "speed",
    difficulty: "advanced",
    xpReward: 150,
    estimatedMinutes: 5,
    requirements: {
      type: "timed_selections",
      count: 5,
      timeLimit: 120, // 2 minutes
      accuracy: 90,
    },
    validation: (state, actions) => {
      const selectionActions = actions.filter((a) => a.type === "make_selection")
      const accurateSelections = selectionActions.filter((a) => a.accuracy >= 90)
      const withinTime = actions[0]?.timestamp && Date.now() - actions[0].timestamp <= 120000
      return {
        completed: accurateSelections.length >= 5 && withinTime,
        progress: accurateSelections.length,
        maxProgress: 5,
      }
    },
    instructions: [
      {
        id: "step1",
        title: "Start Timer",
        instruction: "You have 2 minutes to complete 5 accurate selections",
      },
      {
        id: "step2",
        title: "Use Selection Tools",
        instruction: "Use Marquee, Lasso, and Magic Wand tools efficiently",
      },
      {
        id: "step3",
        title: "Maintain Accuracy",
        instruction: "Each selection must be at least 90% accurate",
      },
    ],
  },
  {
    id: "creative-composition",
    title: "Creative Composition",
    description: "Create an artistic composition using at least 7 layers with different blend modes",
    type: "weekly",
    category: "creative",
    difficulty: "intermediate",
    xpReward: 200,
    estimatedMinutes: 30,
    requirements: {
      type: "creative_project",
      layers: 7,
      blendModes: 3,
      effects: 2,
    },
    validation: (state, actions) => {
      const layers = state.layers || []
      const usedBlendModes = new Set(layers.map((l: any) => l.blendMode))
      const layersWithEffects = layers.filter((l: any) => l.effects && l.effects.length > 0)
      return {
        completed: layers.length >= 7 && usedBlendModes.size >= 3 && layersWithEffects.length >= 2,
        progress: Math.min(layers.length, 7) + Math.min(usedBlendModes.size, 3) + Math.min(layersWithEffects.length, 2),
        maxProgress: 12,
      }
    },
    instructions: [
      {
        id: "step1",
        title: "Plan Your Composition",
        instruction: "Think about what you want to create before starting",
      },
      {
        id: "step2",
        title: "Create Base Layers",
        instruction: "Start with at least 7 layers for your composition",
      },
      {
        id: "step3",
        title: "Experiment with Blend Modes",
        instruction: "Try different blend modes to create interesting effects",
      },
      {
        id: "step4",
        title: "Add Layer Effects",
        instruction: "Apply effects to at least 2 layers to enhance your composition",
      },
    ],
  },
]

export class MissionTracker {
  private actions: any[] = []
  private startTime: number = Date.now()

  addAction(action: any) {
    this.actions.push({
      ...action,
      timestamp: Date.now(),
    })
  }

  validateMission(missionId: string, currentState: any) {
    const mission = missionDefinitions.find((m) => m.id === missionId)
    if (!mission) return null

    return mission.validation(currentState, this.actions)
  }

  getProgress(missionId: string, currentState: any) {
    const validation = this.validateMission(missionId, currentState)
    return validation || { completed: false, progress: 0, maxProgress: 1 }
  }

  reset() {
    this.actions = []
    this.startTime = Date.now()
  }

  getElapsedTime() {
    return Date.now() - this.startTime
  }
}
