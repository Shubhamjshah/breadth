// Authentication utilities using local storage
import { LocalDatabase } from "./database"
import type { User } from "./database"

export interface LoginCredentials {
  email: string
  password: string
}

export interface SignupData {
  email: string
  username: string
  password: string
}

export class AuthService {
  private db = LocalDatabase.getInstance()

  async login(credentials: LoginCredentials): Promise<{ user: User | null; error: string | null }> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const users = this.db.getUsers()
      const user = users.find((u) => u.email === credentials.email)

      if (!user) {
        return { user: null, error: "User not found" }
      }

      // In a real app, you'd verify the password hash
      // For demo purposes, we'll just check if password is not empty
      if (!credentials.password) {
        return { user: null, error: "Invalid password" }
      }

      // Update last login
      const updatedUser = this.db.updateUser(user.id, {
        lastLoginDate: new Date().toISOString(),
      })

      return { user: updatedUser, error: null }
    } catch (error) {
      return { user: null, error: "Login failed" }
    }
  }

  async signup(data: SignupData): Promise<{ user: User | null; error: string | null }> {
    try {
      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 500))

      const users = this.db.getUsers()
      const existingUser = users.find((u) => u.email === data.email)

      if (existingUser) {
        return { user: null, error: "User already exists" }
      }

      const user = this.db.createUser({
        email: data.email,
        username: data.username,
        level: 1,
        xp: 0,
        streak: 0,
        lastLoginDate: new Date().toISOString(),
        preferences: {
          theme: "system",
          notifications: true,
          dailyGoal: 30,
        },
      })

      return { user, error: null }
    } catch (error) {
      return { user: null, error: "Signup failed" }
    }
  }

  logout(): void {
    localStorage.removeItem("currentUser")
  }

  getCurrentUser(): User | null {
    return this.db.getCurrentUser()
  }

  isAuthenticated(): boolean {
    return this.getCurrentUser() !== null
  }
}

export const authService = new AuthService()
