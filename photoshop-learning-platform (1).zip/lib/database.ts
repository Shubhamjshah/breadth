// Database schema and mock data management
export interface User {
  id: string
  email: string
  username: string
  avatar?: string
  createdAt: Date
  level: number
  xp: number
  streak: number
  lastLoginDate: string
  preferences: {
    theme: "light" | "dark" | "system"
    notifications: boolean
    dailyGoal: number
  }
}

export interface Course {
  id: string
  title: string
  description: string
  difficulty: "beginner" | "intermediate" | "advanced"
  lessons: Lesson[]
  prerequisites?: string[]
  estimatedHours: number
  skills: string[]
}

export interface Lesson {
  id: string
  courseId: string
  title: string
  description: string
  type: "tutorial" | "practice" | "quiz" | "mission"
  difficulty: number
  xpReward: number
  content: LessonContent
  prerequisites?: string[]
  estimatedMinutes: number
}

export interface LessonContent {
  steps: LessonStep[]
  resources?: string[]
  finalProject?: string
}

export interface LessonStep {
  id: string
  type: "explanation" | "interactive" | "quiz" | "practice" | "simulation"
  title: string
  content: string
  media?: string
  interactions?: any
  validation?: any
}

export interface UserProgress {
  userId: string
  courseId: string
  lessonId: string
  completed: boolean
  score?: number
  timeSpent: number
  completedAt?: Date
  attempts: number
}

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: "learning" | "streak" | "skill" | "special"
  rarity: "common" | "rare" | "epic" | "legendary"
  requirements: any
  xpReward: number
}

export interface UserAchievement {
  userId: string
  achievementId: string
  unlockedAt: Date
  progress?: number
}

// Mock data
export const mockCourses: Course[] = [
  {
    id: "basics",
    title: "Photoshop Basics",
    description: "Master the fundamentals of Adobe Photoshop",
    difficulty: "beginner",
    estimatedHours: 8,
    skills: ["Interface Navigation", "Basic Tools", "Layers"],
    lessons: [
      {
        id: "interface-tour",
        courseId: "basics",
        title: "Interface Tour",
        description: "Learn your way around Photoshop's interface",
        type: "tutorial",
        difficulty: 1,
        xpReward: 50,
        estimatedMinutes: 15,
        content: {
          steps: [
            {
              id: "step1",
              type: "explanation",
              title: "Welcome to Photoshop",
              content: "Adobe Photoshop is the industry standard for digital image editing and graphic design.",
              media: "/photoshop-interface.png",
            },
            {
              id: "step2",
              type: "interactive",
              title: "Identify the Tools Panel",
              content: "Click on the Tools Panel to continue",
              interactions: { target: "tools-panel", action: "click" },
            },
          ],
        },
      },
      {
        id: "basic-tools",
        courseId: "basics",
        title: "Basic Tools",
        description: "Learn essential Photoshop tools",
        type: "practice",
        difficulty: 2,
        xpReward: 75,
        estimatedMinutes: 20,
        content: {
          steps: [
            {
              id: "step1",
              type: "simulation",
              title: "Use the Move Tool",
              content: "Practice moving objects in your canvas",
              interactions: { tool: "move", task: "move-object" },
            },
          ],
        },
      },
    ],
  },
  {
    id: "layers",
    title: "Mastering Layers",
    description: "Deep dive into Photoshop's layer system",
    difficulty: "intermediate",
    estimatedHours: 6,
    skills: ["Layer Management", "Blend Modes", "Layer Effects"],
    lessons: [],
  },
]

export const mockAchievements: Achievement[] = [
  {
    id: "first-lesson",
    title: "First Steps",
    description: "Complete your first lesson",
    icon: "🎯",
    category: "learning",
    rarity: "common",
    requirements: { lessonsCompleted: 1 },
    xpReward: 25,
  },
  {
    id: "week-streak",
    title: "Week Warrior",
    description: "Maintain a 7-day learning streak",
    icon: "🔥",
    category: "streak",
    rarity: "rare",
    requirements: { streak: 7 },
    xpReward: 100,
  },
  {
    id: "layer-master",
    title: "Layer Master",
    description: "Complete all layer-related lessons",
    icon: "📚",
    category: "skill",
    rarity: "epic",
    requirements: { courseCompleted: "layers" },
    xpReward: 200,
  },
]

// Local storage utilities
export class LocalDatabase {
  private static instance: LocalDatabase

  static getInstance(): LocalDatabase {
    if (!LocalDatabase.instance) {
      LocalDatabase.instance = new LocalDatabase()
    }
    return LocalDatabase.instance
  }

  // User management
  createUser(userData: Omit<User, "id" | "createdAt">): User {
    const user: User = {
      ...userData,
      id: crypto.randomUUID(),
      createdAt: new Date(),
    }

    const users = this.getUsers()
    users.push(user)
    localStorage.setItem("users", JSON.stringify(users))
    localStorage.setItem("currentUser", JSON.stringify(user))

    return user
  }

  getUsers(): User[] {
    const users = localStorage.getItem("users")
    return users ? JSON.parse(users) : []
  }

  getCurrentUser(): User | null {
    const user = localStorage.getItem("currentUser")
    return user ? JSON.parse(user) : null
  }

  updateUser(userId: string, updates: Partial<User>): User | null {
    const users = this.getUsers()
    const userIndex = users.findIndex((u) => u.id === userId)

    if (userIndex === -1) return null

    users[userIndex] = { ...users[userIndex], ...updates }
    localStorage.setItem("users", JSON.stringify(users))

    if (this.getCurrentUser()?.id === userId) {
      localStorage.setItem("currentUser", JSON.stringify(users[userIndex]))
    }

    return users[userIndex]
  }

  // Progress management
  saveProgress(progress: UserProgress): void {
    const allProgress = this.getUserProgress(progress.userId)
    const existingIndex = allProgress.findIndex(
      (p) => p.courseId === progress.courseId && p.lessonId === progress.lessonId,
    )

    if (existingIndex >= 0) {
      allProgress[existingIndex] = progress
    } else {
      allProgress.push(progress)
    }

    localStorage.setItem(`progress_${progress.userId}`, JSON.stringify(allProgress))
  }

  getUserProgress(userId: string): UserProgress[] {
    const progress = localStorage.getItem(`progress_${userId}`)
    return progress ? JSON.parse(progress) : []
  }

  // Achievement management
  unlockAchievement(userId: string, achievementId: string): void {
    const userAchievements = this.getUserAchievements(userId)
    const existing = userAchievements.find((ua) => ua.achievementId === achievementId)

    if (!existing) {
      userAchievements.push({
        userId,
        achievementId,
        unlockedAt: new Date(),
      })
      localStorage.setItem(`achievements_${userId}`, JSON.stringify(userAchievements))
    }
  }

  getUserAchievements(userId: string): UserAchievement[] {
    const achievements = localStorage.getItem(`achievements_${userId}`)
    return achievements ? JSON.parse(achievements) : []
  }

  // Course and lesson data
  getCourses(): Course[] {
    return mockCourses
  }

  getCourse(courseId: string): Course | null {
    return mockCourses.find((c) => c.id === courseId) || null
  }

  getLesson(courseId: string, lessonId: string): Lesson | null {
    const course = this.getCourse(courseId)
    return course?.lessons.find((l) => l.id === lessonId) || null
  }

  getAchievements(): Achievement[] {
    return mockAchievements
  }
}
