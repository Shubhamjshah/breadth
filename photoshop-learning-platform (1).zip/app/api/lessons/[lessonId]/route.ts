import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest, { params }: { params: { lessonId: string } }) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const courseId = searchParams.get("courseId")

    if (!courseId) {
      return NextResponse.json({ error: "Course ID is required" }, { status: 400 })
    }

    const lesson = db.getLesson(courseId, params.lessonId)
    if (!lesson) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 })
    }

    const userProgress = db.getUserProgress(user.id)
    const lessonProgress = userProgress.find((p) => p.courseId === courseId && p.lessonId === params.lessonId)

    return NextResponse.json({
      ...lesson,
      progress: lessonProgress || null,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch lesson" }, { status: 500 })
  }
}

export async function POST(request: NextRequest, { params }: { params: { lessonId: string } }) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { courseId, completed, score, timeSpent } = await request.json()

    if (!courseId) {
      return NextResponse.json({ error: "Course ID is required" }, { status: 400 })
    }

    const lesson = db.getLesson(courseId, params.lessonId)
    if (!lesson) {
      return NextResponse.json({ error: "Lesson not found" }, { status: 404 })
    }

    // Save progress
    const existingProgress = db.getUserProgress(user.id)
    const lessonProgress = existingProgress.find((p) => p.courseId === courseId && p.lessonId === params.lessonId)

    db.saveProgress({
      userId: user.id,
      courseId,
      lessonId: params.lessonId,
      completed: completed || false,
      score: score || lessonProgress?.score,
      timeSpent: (lessonProgress?.timeSpent || 0) + (timeSpent || 0),
      attempts: (lessonProgress?.attempts || 0) + 1,
      completedAt: completed ? new Date() : lessonProgress?.completedAt,
    })

    // Award XP and check achievements if lesson completed
    if (completed && !lessonProgress?.completed) {
      const updatedUser = db.updateUser(user.id, {
        xp: user.xp + lesson.xpReward,
        level: Math.floor((user.xp + lesson.xpReward) / 100) + 1,
      })

      // Check for achievements
      const allProgress = db.getUserProgress(user.id)
      const completedLessons = allProgress.filter((p) => p.completed).length

      if (completedLessons === 1) {
        db.unlockAchievement(user.id, "first-lesson")
      }

      return NextResponse.json({
        success: true,
        xpEarned: lesson.xpReward,
        newLevel: updatedUser?.level,
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to update lesson progress" }, { status: 500 })
  }
}
