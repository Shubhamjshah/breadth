import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Gather all user data
    const userProgress = db.getUserProgress(user.id)
    const userAchievements = db.getUserAchievements(user.id)

    const exportData = {
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        level: user.level,
        xp: user.xp,
        streak: user.streak,
        createdAt: user.createdAt,
        preferences: user.preferences,
      },
      progress: userProgress,
      achievements: userAchievements,
      exportedAt: new Date().toISOString(),
      version: "1.0",
    }

    return NextResponse.json(exportData, {
      headers: {
        "Content-Disposition": `attachment; filename="photoshop-academy-data-${user.username}.json"`,
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to export user data" }, { status: 500 })
  }
}
