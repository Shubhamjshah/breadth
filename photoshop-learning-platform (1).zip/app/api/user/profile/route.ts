import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get enhanced user data with statistics
    const userProgress = db.getUserProgress(user.id)
    const userAchievements = db.getUserAchievements(user.id)

    const completedLessons = userProgress.filter((p) => p.completed).length
    const totalTimeSpent = userProgress.reduce((sum, p) => sum + p.timeSpent, 0)

    const enhancedUser = {
      ...user,
      stats: {
        lessonsCompleted: completedLessons,
        timeSpent: Math.round(totalTimeSpent / 60), // Convert to minutes
        achievementsUnlocked: userAchievements.length,
        currentStreak: user.streak,
      },
    }

    return NextResponse.json({ user: enhancedUser })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch user profile" }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const updates = await request.json()

    // Validate updates (prevent updating sensitive fields)
    const allowedFields = ["username", "avatar", "preferences"]
    const filteredUpdates = Object.keys(updates)
      .filter((key) => allowedFields.includes(key))
      .reduce((obj, key) => {
        obj[key] = updates[key]
        return obj
      }, {} as any)

    const updatedUser = db.updateUser(user.id, filteredUpdates)

    if (!updatedUser) {
      return NextResponse.json({ error: "Failed to update user" }, { status: 400 })
    }

    return NextResponse.json({ user: updatedUser })
  } catch (error) {
    return NextResponse.json({ error: "Failed to update user profile" }, { status: 500 })
  }
}
