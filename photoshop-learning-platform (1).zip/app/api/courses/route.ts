import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const courses = db.getCourses()
    const userProgress = db.getUserProgress(user.id)

    // Enhance courses with progress data
    const coursesWithProgress = courses.map((course) => {
      const courseProgress = userProgress.filter((p) => p.courseId === course.id)
      const completedLessons = courseProgress.filter((p) => p.completed).length
      const totalLessons = course.lessons.length

      return {
        ...course,
        progress: {
          completed: completedLessons,
          total: totalLessons,
          percentage: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
        },
      }
    })

    return NextResponse.json({ courses: coursesWithProgress })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch courses" }, { status: 500 })
  }
}
