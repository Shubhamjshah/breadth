import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest, { params }: { params: { courseId: string } }) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const course = db.getCourse(params.courseId)
    if (!course) {
      return NextResponse.json({ error: "Course not found" }, { status: 404 })
    }

    const userProgress = db.getUserProgress(user.id)
    const courseProgress = userProgress.filter((p) => p.courseId === params.courseId)

    // Enhance lessons with progress data
    const lessonsWithProgress = course.lessons.map((lesson) => {
      const lessonProgress = courseProgress.find((p) => p.lessonId === lesson.id)
      return {
        ...lesson,
        completed: lessonProgress?.completed || false,
        score: lessonProgress?.score,
        timeSpent: lessonProgress?.timeSpent || 0,
        attempts: lessonProgress?.attempts || 0,
      }
    })

    return NextResponse.json({
      ...course,
      lessons: lessonsWithProgress,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch course" }, { status: 500 })
  }
}
