import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userProgress = db.getUserProgress(user.id)
    const userAchievements = db.getUserAchievements(user.id)
    const courses = db.getCourses()

    // Calculate comprehensive statistics
    const completedLessons = userProgress.filter((p) => p.completed)
    const totalTimeSpent = userProgress.reduce((sum, p) => sum + p.timeSpent, 0)
    const averageScore = userProgress
      .filter((p) => p.score)
      .reduce((sum, p, _, arr) => sum + (p.score || 0) / arr.length, 0)

    // Weekly progress (last 7 days)
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    const weeklyLessons = completedLessons.filter((p) => p.completedAt && new Date(p.completedAt) > weekAgo)

    // Course progress breakdown
    const courseStats = courses.map((course) => {
      const courseProgress = userProgress.filter((p) => p.courseId === course.id)
      const completed = courseProgress.filter((p) => p.completed).length
      const total = course.lessons.length

      return {
        courseId: course.id,
        title: course.title,
        completed,
        total,
        percentage: total > 0 ? Math.round((completed / total) * 100) : 0,
        timeSpent: courseProgress.reduce((sum, p) => sum + p.timeSpent, 0),
      }
    })

    // Skill distribution
    const skillStats = courses.reduce(
      (acc, course) => {
        const courseProgress = userProgress.filter((p) => p.courseId === course.id && p.completed)
        course.skills.forEach((skill) => {
          acc[skill] = (acc[skill] || 0) + courseProgress.length
        })
        return acc
      },
      {} as Record<string, number>,
    )

    // Learning streak calculation
    const streakDays = []
    for (let i = 0; i < 30; i++) {
      const date = new Date(Date.now() - i * 24 * 60 * 60 * 1000)
      const dayLessons = completedLessons.filter(
        (p) => p.completedAt && new Date(p.completedAt).toDateString() === date.toDateString(),
      ).length
      streakDays.push({ date: date.toISOString().split("T")[0], lessons: dayLessons })
    }

    return NextResponse.json({
      overview: {
        totalLessons: completedLessons.length,
        totalTimeSpent: Math.round(totalTimeSpent / 60), // Convert to minutes
        averageScore: Math.round(averageScore),
        currentStreak: user.streak,
        level: user.level,
        xp: user.xp,
        xpToNextLevel: user.level * 100 - user.xp,
        achievementsUnlocked: userAchievements.length,
      },
      weekly: {
        lessonsCompleted: weeklyLessons.length,
        timeSpent: Math.round(weeklyLessons.reduce((sum, p) => sum + p.timeSpent, 0) / 60),
        averageDaily: Math.round((weeklyLessons.length / 7) * 10) / 10,
      },
      courses: courseStats,
      skills: Object.entries(skillStats).map(([skill, count]) => ({ skill, count })),
      streakData: streakDays.reverse(),
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch statistics" }, { status: 500 })
  }
}
