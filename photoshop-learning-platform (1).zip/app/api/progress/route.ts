import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function POST(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const progressData = await request.json()

    db.saveProgress({
      userId: user.id,
      ...progressData,
      completedAt: progressData.completed ? new Date() : undefined,
    })

    // Check for achievements
    const userProgress = db.getUserProgress(user.id)
    const completedLessons = userProgress.filter((p) => p.completed).length

    // Unlock "First Steps" achievement
    if (completedLessons === 1) {
      db.unlockAchievement(user.id, "first-lesson")
    }

    // Update user XP
    if (progressData.completed && progressData.xpReward) {
      const updatedUser = db.updateUser(user.id, {
        xp: user.xp + progressData.xpReward,
        level: Math.floor((user.xp + progressData.xpReward) / 100) + 1,
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to save progress" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const progress = db.getUserProgress(user.id)
    return NextResponse.json({ progress })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch progress" }, { status: 500 })
  }
}
