import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"
import { missionDefinitions } from "@/lib/missions"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const userProgress = db.getUserProgress(user.id)
    const today = new Date().toDateString()
    const thisWeek = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)

    // Calculate mission progress based on user actions and progress
    const missionsWithProgress = missionDefinitions.map((mission) => {
      let progress = 0
      let completed = false

      // Get mission-specific progress from localStorage or calculate based on requirements
      const missionProgress = localStorage.getItem(`mission_${mission.id}_${user.id}`)
      if (missionProgress) {
        const parsed = JSON.parse(missionProgress)
        progress = parsed.progress || 0
        completed = parsed.completed || false
      } else {
        // Calculate progress based on mission type and user data
        switch (mission.requirements.type) {
          case "move_layers":
            // Count unique layers moved today
            const todayProgress = userProgress.filter(
              (p) => p.completedAt && new Date(p.completedAt).toDateString() === today,
            )
            progress = Math.min(todayProgress.length, mission.requirements.count || 1)
            completed = progress >= (mission.requirements.count || 1)
            break

          case "create_layers":
            // This would be tracked during simulator use
            progress = 0
            completed = false
            break

          case "brush_accuracy":
            // This would be tracked during simulator use
            progress = 0
            completed = false
            break

          case "timed_selections":
            // This would be tracked during simulator use
            progress = 0
            completed = false
            break

          case "creative_project":
            // This would be tracked during simulator use
            progress = 0
            completed = false
            break
        }
      }

      // Set deadline based on mission type
      let deadline = null
      if (mission.type === "daily") {
        deadline = new Date(Date.now() + 24 * 60 * 60 * 1000)
      } else if (mission.type === "weekly") {
        deadline = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      }

      return {
        ...mission,
        progress,
        maxProgress: mission.requirements.count || mission.requirements.layers || 1,
        completed,
        deadline: deadline?.toISOString(),
      }
    })

    return NextResponse.json({ missions: missionsWithProgress })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch missions" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { missionId, progress, completed, actions } = await request.json()

    if (missionId && progress !== undefined) {
      // Update mission progress
      localStorage.setItem(
        `mission_${missionId}_${user.id}`,
        JSON.stringify({
          progress,
          completed: completed || false,
          lastUpdated: new Date().toISOString(),
          actions: actions || [],
        }),
      )

      // Award XP if mission completed
      if (completed) {
        const mission = missionDefinitions.find((m) => m.id === missionId)
        if (mission) {
          const updatedUser = db.updateUser(user.id, {
            xp: user.xp + mission.xpReward,
            level: Math.floor((user.xp + mission.xpReward) / 100) + 1,
          })

          return NextResponse.json({
            success: true,
            xpEarned: mission.xpReward,
            newLevel: updatedUser?.level,
          })
        }
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to update mission" }, { status: 500 })
  }
}
