import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const allAchievements = db.getAchievements()
    const userAchievements = db.getUserAchievements(user.id)
    const userProgress = db.getUserProgress(user.id)

    // Enhance achievements with user progress
    const achievementsWithProgress = allAchievements.map((achievement) => {
      const userAchievement = userAchievements.find((ua) => ua.achievementId === achievement.id)
      let progress = 0

      // Calculate progress based on requirements
      if (!userAchievement) {
        switch (achievement.id) {
          case "first-lesson":
            progress = Math.min(userProgress.filter((p) => p.completed).length, 1)
            break
          case "week-streak":
            progress = Math.min(user.streak, 7)
            break
          case "layer-master":
            const layerLessons = userProgress.filter((p) => p.courseId === "layers" && p.completed)
            const totalLayerLessons = db.getCourse("layers")?.lessons.length || 1
            progress = Math.min(layerLessons.length, totalLayerLessons)
            break
        }
      }

      return {
        ...achievement,
        unlocked: !!userAchievement,
        unlockedAt: userAchievement?.unlockedAt,
        progress: userAchievement
          ? achievement.requirements.lessonsCompleted || achievement.requirements.streak || 1
          : progress,
        maxProgress: achievement.requirements.lessonsCompleted || achievement.requirements.streak || 1,
      }
    })

    return NextResponse.json({ achievements: achievementsWithProgress })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch achievements" }, { status: 500 })
  }
}
