import { type NextRequest, NextResponse } from "next/server"
import { LocalDatabase } from "@/lib/database"
import { authService } from "@/lib/auth"

const db = LocalDatabase.getInstance()

export async function GET(request: NextRequest) {
  try {
    const user = authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "xp" // xp, streak, lessons

    const users = db.getUsers()

    // Sort users based on leaderboard type
    const sortedUsers = [...users]
    switch (type) {
      case "xp":
        sortedUsers.sort((a, b) => b.xp - a.xp)
        break
      case "streak":
        sortedUsers.sort((a, b) => b.streak - a.streak)
        break
      case "lessons":
        sortedUsers.sort((a, b) => {
          const aLessons = db.getUserProgress(a.id).filter((p) => p.completed).length
          const bLessons = db.getUserProgress(b.id).filter((p) => p.completed).length
          return bLessons - aLessons
        })
        break
    }

    // Get top 10 and current user position
    const top10 = sortedUsers.slice(0, 10).map((u, index) => {
      const progress = db.getUserProgress(u.id)
      const completedLessons = progress.filter((p) => p.completed).length
      const totalTimeSpent = progress.reduce((sum, p) => sum + p.timeSpent, 0)

      return {
        rank: index + 1,
        id: u.id,
        username: u.username,
        avatar: u.avatar,
        level: u.level,
        xp: u.xp,
        streak: u.streak,
        lessonsCompleted: completedLessons,
        timeSpent: totalTimeSpent,
      }
    })

    const currentUserRank = sortedUsers.findIndex((u) => u.id === user.id) + 1

    return NextResponse.json({
      leaderboard: top10,
      currentUserRank,
      type,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch leaderboard" }, { status: 500 })
  }
}
