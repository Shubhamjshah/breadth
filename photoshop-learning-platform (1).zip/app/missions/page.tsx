"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useRouter } from "next/navigation"

interface Mission {
  id: string
  title: string
  description: string
  type: "daily" | "weekly" | "challenge"
  category: "tools" | "techniques" | "creative" | "speed"
  difficulty: "beginner" | "intermediate" | "advanced"
  xpReward: number
  requirements: any
  progress: number
  maxProgress: number
  completed: boolean
  deadline?: string
  estimatedMinutes: number
}

export default function MissionsPage() {
  const [missions, setMissions] = useState<Mission[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const router = useRouter()

  useEffect(() => {
    fetchMissions()
  }, [])

  const fetchMissions = async () => {
    try {
      const response = await fetch("/api/missions")
      const data = await response.json()
      setMissions(data.missions || [])
    } catch (error) {
      console.error("Failed to fetch missions:", error)
    } finally {
      setLoading(false)
    }
  }

  const startMission = (mission: Mission) => {
    // Navigate to simulator with mission context
    router.push(`/simulator?mission=${mission.id}`)
  }

  const claimReward = async (missionId: string) => {
    try {
      const response = await fetch("/api/missions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ missionId }),
      })

      if (response.ok) {
        fetchMissions() // Refresh missions
      }
    } catch (error) {
      console.error("Failed to claim reward:", error)
    }
  }

  const filteredMissions = missions.filter((mission) => {
    if (selectedCategory === "all") return true
    return mission.category === selectedCategory
  })

  const getMissionIcon = (category: string) => {
    switch (category) {
      case "tools":
        return "🛠"
      case "techniques":
        return "🎨"
      case "creative":
        return "✨"
      case "speed":
        return "⚡"
      default:
        return "📋"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-500"
      case "intermediate":
        return "bg-yellow-500"
      case "advanced":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">Loading missions...</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Photoshop Missions</h1>
        <p className="text-muted-foreground">Complete hands-on challenges to master Photoshop skills</p>
      </div>

      <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">All Missions</TabsTrigger>
          <TabsTrigger value="tools">Tools</TabsTrigger>
          <TabsTrigger value="techniques">Techniques</TabsTrigger>
          <TabsTrigger value="creative">Creative</TabsTrigger>
          <TabsTrigger value="speed">Speed</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedCategory} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredMissions.map((mission) => (
              <Card key={mission.id} className="relative overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-2">
                      <span className="text-2xl">{getMissionIcon(mission.category)}</span>
                      <div>
                        <CardTitle className="text-lg">{mission.title}</CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className={`${getDifficultyColor(mission.difficulty)} text-white`}>
                            {mission.difficulty}
                          </Badge>
                          <Badge variant="secondary">{mission.type}</Badge>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold text-lime-600">+{mission.xpReward} XP</div>
                      <div className="text-xs text-muted-foreground">{mission.estimatedMinutes} min</div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <CardDescription>{mission.description}</CardDescription>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>
                        {mission.progress}/{mission.maxProgress}
                      </span>
                    </div>
                    <Progress value={(mission.progress / mission.maxProgress) * 100} className="h-2" />
                  </div>

                  {/* Deadline */}
                  {mission.deadline && (
                    <div className="text-xs text-muted-foreground">
                      Deadline: {new Date(mission.deadline).toLocaleDateString()}
                    </div>
                  )}

                  {/* Action Button */}
                  <div className="pt-2">
                    {mission.completed ? (
                      <Button onClick={() => claimReward(mission.id)} className="w-full" variant="outline">
                        Claim Reward
                      </Button>
                    ) : (
                      <Button onClick={() => startMission(mission)} className="w-full">
                        {mission.progress > 0 ? "Continue Mission" : "Start Mission"}
                      </Button>
                    )}
                  </div>
                </CardContent>

                {/* Completion Overlay */}
                {mission.completed && (
                  <div className="absolute inset-0 bg-green-500/10 flex items-center justify-center">
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      Completed!
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>

          {filteredMissions.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No missions available in this category.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
