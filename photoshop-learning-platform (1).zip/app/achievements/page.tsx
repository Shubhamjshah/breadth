import { Header } from "@/components/header"
import { AchievementGallery } from "@/components/achievement-gallery"
import { BadgeCollection } from "@/components/badge-collection"
import { AchievementStats } from "@/components/achievement-stats"

export default function AchievementsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          <div className="text-center space-y-2">
            <h1 className="font-heading text-3xl font-bold text-gray-900">Achievement Gallery</h1>
            <p className="text-lg text-gray-600">Celebrate your learning milestones and unlock special badges!</p>
          </div>

          <AchievementStats />

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <AchievementGallery />
            </div>
            <div>
              <BadgeCollection />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
