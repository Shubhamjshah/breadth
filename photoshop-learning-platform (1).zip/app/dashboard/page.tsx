import { Header } from "@/components/header"
import { ProgressDashboard } from "@/components/progress-dashboard"
import { Leaderboard } from "@/components/leaderboard"
import { ChallengeCenter } from "@/components/challenge-center"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          <div className="text-center space-y-2">
            <h1 className="font-heading text-3xl font-bold text-gray-900">Your Learning Dashboard</h1>
            <p className="text-lg text-gray-600">Track your progress and celebrate your achievements!</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <ProgressDashboard />
            </div>
            <div className="space-y-6">
              <ChallengeCenter />
              <Leaderboard />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
