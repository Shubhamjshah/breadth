import { Header } from "@/components/header"
import { UserProfile } from "@/components/user-profile"
import { ProfileStats } from "@/components/profile-stats"
import { LearningGoals } from "@/components/learning-goals"
import { RecentActivity } from "@/components/recent-activity"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <UserProfile />
          </div>
          <div className="lg:col-span-2 space-y-6">
            <ProfileStats />
            <div className="grid md:grid-cols-2 gap-6">
              <LearningGoals />
              <RecentActivity />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
