import { Header } from "@/components/header"
import { CourseMap } from "@/components/course-map"
import { ProgressStats } from "@/components/progress-stats"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <ProgressStats />
          </div>
          <div className="lg:col-span-3">
            <CourseMap />
          </div>
        </div>
      </main>
    </div>
  )
}
