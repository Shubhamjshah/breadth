import { UserSettings } from "@/components/user-management/user-settings"

export default function SettingsPage() {
  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="space-y-2 mb-6">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your account and learning preferences</p>
      </div>
      <UserSettings />
    </div>
  )
}
