"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { PhotoshopInterface } from "@/components/photoshop-simulator/photoshop-interface"
import { MissionTrackerComponent } from "@/components/photoshop-simulator/mission-tracker"
import type { PhotoshopState } from "@/components/photoshop-simulator/photoshop-interface"
import { toast } from "sonner"

export default function SimulatorPage() {
  const searchParams = useSearchParams()
  const missionId = searchParams.get("mission")
  const [photoshopState, setPhotoshopState] = useState<PhotoshopState | null>(null)

  const handleMissionComplete = (missionId: string, xpEarned: number) => {
    toast.success(`Mission completed! +${xpEarned} XP earned`, {
      duration: 5000,
    })
  }

  return (
    <div className="h-screen relative">
      <PhotoshopInterface onStateChange={setPhotoshopState} />
      {missionId && photoshopState && (
        <MissionTrackerComponent
          missionId={missionId}
          photoshopState={photoshopState}
          onMissionComplete={handleMissionComplete}
        />
      )}
    </div>
  )
}
