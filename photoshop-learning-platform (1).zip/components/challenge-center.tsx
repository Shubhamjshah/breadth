"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Zap, Trophy, Clock, Star } from "lucide-react"

const challenges = [
  {
    id: 1,
    title: "Daily Streak",
    description: "Complete at least 1 lesson every day",
    type: "daily",
    progress: 7,
    target: 7,
    reward: 50,
    timeLeft: "Resets in 6h",
    completed: true,
  },
  {
    id: 2,
    title: "Weekly Master",
    description: "Master 3 new tools this week",
    type: "weekly",
    progress: 1,
    target: 3,
    reward: 200,
    timeLeft: "3 days left",
    completed: false,
  },
  {
    id: 3,
    title: "Speed Runner",
    description: "Complete 5 lessons in under 2 hours",
    type: "special",
    progress: 2,
    target: 5,
    reward: 150,
    timeLeft: "1h 30m left",
    completed: false,
  },
]

export function ChallengeCenter() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Zap className="w-5 h-5 text-purple-600" />
          Challenge Center
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {challenges.map((challenge) => (
            <div
              key={challenge.id}
              className={`p-4 rounded-lg border ${
                challenge.completed ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-sm">{challenge.title}</h4>
                      <Badge
                        variant={
                          challenge.type === "daily" ? "default" : challenge.type === "weekly" ? "secondary" : "outline"
                        }
                        className="text-xs"
                      >
                        {challenge.type}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{challenge.description}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {challenge.timeLeft}
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200 text-xs">
                      <Trophy className="w-3 h-3 mr-1" />+{challenge.reward} XP
                    </Badge>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>Progress</span>
                    <span>
                      {challenge.progress}/{challenge.target}
                    </span>
                  </div>
                  <Progress value={(challenge.progress / challenge.target) * 100} className="h-2" />
                </div>

                {challenge.completed && (
                  <div className="flex items-center gap-2 text-green-600 text-xs">
                    <Star className="w-3 h-3" />
                    Challenge Completed!
                  </div>
                )}
              </div>
            </div>
          ))}

          <Button variant="outline" className="w-full text-sm bg-transparent">
            View All Challenges
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
