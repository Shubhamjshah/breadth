"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { useAuth } from "@/contexts/auth-context"

interface OnboardingFlowProps {
  onComplete: () => void
}

export function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    experience: "",
    goals: [] as string[],
    dailyGoal: 30,
    notifications: true,
    avatar: "",
  })
  const { updateUser } = useAuth()

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1)
    } else {
      completeOnboarding()
    }
  }

  const handlePrevious = () => {
    if (step > 1) {
      setStep(step - 1)
    }
  }

  const completeOnboarding = async () => {
    await updateUser({
      preferences: {
        ...formData,
        onboardingCompleted: true,
      },
    })
    onComplete()
  }

  const toggleGoal = (goal: string) => {
    setFormData((prev) => ({
      ...prev,
      goals: prev.goals.includes(goal) ? prev.goals.filter((g) => g !== goal) : [...prev.goals, goal],
    }))
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="experience">What's your Photoshop experience level?</Label>
              <Select
                value={formData.experience}
                onValueChange={(value) => setFormData({ ...formData, experience: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select your experience level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Complete Beginner</SelectItem>
                  <SelectItem value="some-experience">Some Experience</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <Label>What are your learning goals? (Select all that apply)</Label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {[
                  "Photo Editing",
                  "Digital Art",
                  "Web Design",
                  "Print Design",
                  "Photo Retouching",
                  "Logo Design",
                  "Social Media Graphics",
                  "Professional Skills",
                ].map((goal) => (
                  <div key={goal} className="flex items-center space-x-2">
                    <Checkbox
                      id={goal}
                      checked={formData.goals.includes(goal)}
                      onCheckedChange={() => toggleGoal(goal)}
                    />
                    <Label htmlFor={goal} className="text-sm">
                      {goal}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="dailyGoal">Daily learning goal (minutes)</Label>
              <Select
                value={formData.dailyGoal.toString()}
                onValueChange={(value) => setFormData({ ...formData, dailyGoal: Number.parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="90">1.5 hours</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="notifications"
                checked={formData.notifications}
                onCheckedChange={(checked) => setFormData({ ...formData, notifications: !!checked })}
              />
              <Label htmlFor="notifications">Send me daily learning reminders</Label>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-4 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h3 className="text-xl font-semibold">You're all set!</h3>
            <p className="text-muted-foreground">
              Welcome to Photoshop Academy! Your personalized learning journey is ready to begin.
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Your Learning Plan:</h4>
              <ul className="text-sm space-y-1">
                <li>Experience Level: {formData.experience}</li>
                <li>Daily Goal: {formData.dailyGoal} minutes</li>
                <li>Focus Areas: {formData.goals.join(", ")}</li>
              </ul>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle>Welcome to Photoshop Academy</CardTitle>
          <CardDescription>Let's personalize your learning experience</CardDescription>
          <div className="flex justify-center space-x-2 mt-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`w-3 h-3 rounded-full ${i <= step ? "bg-cyan-600" : "bg-gray-300"}`} />
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {renderStep()}
          <div className="flex justify-between">
            <Button variant="outline" onClick={handlePrevious} disabled={step === 1}>
              Previous
            </Button>
            <Button onClick={handleNext}>{step === 4 ? "Get Started" : "Next"}</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
