"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Target, TrendingUp, Flame, Trophy, Star, Zap, Award } from "lucide-react"
import { useState } from "react"

export function ProgressStats() {
  const [currentLevel] = useState(12)
  const [currentXP] = useState(1325)
  const [xpToNextLevel] = useState(1500)
  const [streak] = useState(7)

  return (
    <div className="space-y-6">
      {/* Level & XP */}
      <Card className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white">
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Star className="w-5 h-5" />
            Level {currentLevel}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>{currentXP} XP</span>
              <span>{xpToNextLevel} XP</span>
            </div>
            <Progress value={(currentXP / xpToNextLevel) * 100} className="h-3 bg-white/20" />
            <p className="text-xs opacity-90">
              {xpToNextLevel - currentXP} XP to level {currentLevel + 1}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Daily Goal */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Target className="w-5 h-5 text-lime-600" />
            Daily Goal
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>3/5 lessons</span>
              <span className="text-muted-foreground">60%</span>
            </div>
            <Progress value={60} className="h-2" />
            <p className="text-xs text-muted-foreground">2 more lessons to reach your daily goal!</p>
            <div className="flex gap-2">
              <Badge variant="secondary" className="text-xs">
                +50 XP bonus
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Streak */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-500" />
            Learning Streak
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-3">
            <div className="text-3xl font-bold text-orange-600">{streak}</div>
            <p className="text-sm text-muted-foreground">days in a row</p>
            <div className="flex justify-center gap-1">
              {[...Array(7)].map((_, i) => (
                <div
                  key={i}
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                    i < streak ? "bg-orange-500 text-white" : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <Flame className="w-3 h-3" />
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Challenge */}
      <Card className="border-purple-200 bg-purple-50">
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Zap className="w-5 h-5 text-purple-600" />
            Weekly Challenge
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <h4 className="font-semibold text-purple-900">Master 3 New Tools</h4>
            <p className="text-sm text-purple-700">Learn Brush, Clone Stamp, and Healing tools this week</p>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span className="text-purple-600">1/3 tools</span>
              </div>
              <Progress value={33} className="h-2" />
            </div>
            <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">
              <Trophy className="w-3 h-3 mr-1" />
              +200 XP Reward
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Recent Achievements */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-600" />
            Recent Achievements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-2 bg-yellow-50 rounded-lg">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <Trophy className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Week Warrior</p>
                <p className="text-xs text-muted-foreground">Complete 7 days in a row</p>
              </div>
              <Badge variant="secondary" className="text-xs">
                +100 XP
              </Badge>
            </div>
            <div className="flex items-center gap-3 p-2 bg-blue-50 rounded-lg">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <Star className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">Tool Master</p>
                <p className="text-xs text-muted-foreground">Master 5 Photoshop tools</p>
              </div>
              <Badge variant="secondary" className="text-xs">
                +150 XP
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-600" />
            This Week
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">18</div>
              <div className="text-xs text-muted-foreground">Lessons</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">4h 32m</div>
              <div className="text-xs text-muted-foreground">Time</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">850</div>
              <div className="text-xs text-muted-foreground">XP Gained</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">95%</div>
              <div className="text-xs text-muted-foreground">Accuracy</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
