"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, ArrowRight, Home } from "lucide-react"
import { ExplanationStep } from "@/components/lesson-steps/explanation-step"
import { InteractiveStep } from "@/components/lesson-steps/interactive-step"
import { QuizStep } from "@/components/lesson-steps/quiz-step"
import { PracticeStep } from "@/components/lesson-steps/practice-step"
import { CompletionStep } from "@/components/lesson-steps/completion-step"
import { DragDropStep } from "@/components/lesson-steps/drag-drop-step"
import Link from "next/link"

interface Lesson {
  id: string
  title: string
  course: string
  type: string
  progress: number
  totalSteps: number
  content: {
    introduction: string
    steps: any[]
  }
}

interface LessonInterfaceProps {
  lesson: Lesson
}

export function LessonInterface({ lesson }: LessonInterfaceProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [stepProgress, setStepProgress] = useState<Record<number, boolean>>({})
  const [showIntro, setShowIntro] = useState(true)

  const progress = (Object.keys(stepProgress).length / lesson.content.steps.length) * 100

  const handleStepComplete = (stepIndex: number) => {
    setStepProgress((prev) => ({ ...prev, [stepIndex]: true }))
  }

  const nextStep = () => {
    if (currentStep < lesson.content.steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const renderStep = (step: any, index: number) => {
    const commonProps = {
      step,
      onComplete: () => handleStepComplete(index),
      isCompleted: stepProgress[index] || false,
    }

    switch (step.type) {
      case "explanation":
        return <ExplanationStep {...commonProps} />
      case "interactive":
        return <InteractiveStep {...commonProps} />
      case "quiz":
        return <QuizStep {...commonProps} />
      case "practice":
        return <PracticeStep {...commonProps} />
      case "drag-drop":
        return <DragDropStep {...commonProps} />
      case "completion":
        return <CompletionStep {...commonProps} />
      default:
        return <div>Unknown step type</div>
    }
  }

  if (showIntro) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader className="text-center">
                <Badge variant="secondary" className="w-fit mx-auto mb-4">
                  {lesson.course}
                </Badge>
                <CardTitle className="font-heading text-2xl">{lesson.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-center text-muted-foreground text-lg">{lesson.content.introduction}</p>

                <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                  <span>{lesson.content.steps.length} steps</span>
                  <span>•</span>
                  <span>~5 minutes</span>
                  <span>•</span>
                  <span>+{lesson.content.steps.find((s) => s.type === "completion")?.xpGained || 50} XP</span>
                </div>

                <div className="flex gap-4 justify-center">
                  <Button variant="outline" asChild>
                    <Link href="/">
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Back to Courses
                    </Link>
                  </Button>
                  <Button onClick={() => setShowIntro(false)} className="bg-cyan-600 hover:bg-cyan-700">
                    Start Lesson
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-lime-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/">
                  <Home className="w-4 h-4" />
                </Link>
              </Button>
              <div>
                <h1 className="font-heading text-lg font-semibold">{lesson.title}</h1>
                <p className="text-sm text-muted-foreground">{lesson.course}</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground">
                Step {currentStep + 1} of {lesson.content.steps.length}
              </div>
              <div className="w-32">
                <Progress value={progress} className="h-2" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-8">{renderStep(lesson.content.steps[currentStep], currentStep)}</CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex justify-between mt-6">
            <Button variant="outline" onClick={prevStep} disabled={currentStep === 0}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Button>

            <Button
              onClick={nextStep}
              disabled={currentStep === lesson.content.steps.length - 1 || !stepProgress[currentStep]}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
