"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Edit, Save, X, MapPin, Calendar, Star, Trophy, Flame } from "lucide-react"

export function UserProfile() {
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: "Jordan Davis",
    bio: "Aspiring graphic designer passionate about learning Photoshop. Love creating digital art and photo manipulations!",
    location: "San Francisco, CA",
    joinDate: "January 2024",
    level: 12,
    xp: 1325,
    streak: 7,
    achievements: 12,
    learningGoal: "intermediate",
    dailyGoal: 5,
  })

  const handleSave = () => {
    setIsEditing(false)
    // In a real app, this would save to a database
  }

  const handleCancel = () => {
    setIsEditing(false)
    // Reset any changes
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="font-heading text-lg">Profile</CardTitle>
            {!isEditing ? (
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={handleCancel}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Avatar and Basic Info */}
          <div className="text-center space-y-4">
            <Avatar className="w-24 h-24 mx-auto">
              <AvatarImage src="/diverse-user-avatars.png" />
              <AvatarFallback className="bg-cyan-100 text-cyan-800 text-2xl">JD</AvatarFallback>
            </Avatar>

            {isEditing ? (
              <div className="space-y-3">
                <div>
                  <Label htmlFor="name" className="text-sm font-medium">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={profile.name}
                    onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="bio" className="text-sm font-medium">
                    Bio
                  </Label>
                  <Textarea
                    id="bio"
                    value={profile.bio}
                    onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                    className="mt-1 min-h-[80px]"
                  />
                </div>
                <div>
                  <Label htmlFor="location" className="text-sm font-medium">
                    Location
                  </Label>
                  <Input
                    id="location"
                    value={profile.location}
                    onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                    className="mt-1"
                  />
                </div>
              </div>
            ) : (
              <>
                <div>
                  <h2 className="font-heading text-xl font-bold">{profile.name}</h2>
                  <Badge className="bg-cyan-100 text-cyan-800 hover:bg-cyan-200 mt-2">
                    <Star className="w-3 h-3 mr-1" />
                    Level {profile.level}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{profile.bio}</p>
                <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {profile.location}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Joined {profile.joinDate}
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-orange-600 mb-1">
                <Flame className="w-4 h-4" />
              </div>
              <div className="text-2xl font-bold text-orange-600">{profile.streak}</div>
              <div className="text-xs text-muted-foreground">Day Streak</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-purple-600 mb-1">
                <Star className="w-4 h-4" />
              </div>
              <div className="text-2xl font-bold text-purple-600">{profile.xp}</div>
              <div className="text-xs text-muted-foreground">Total XP</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 text-yellow-600 mb-1">
                <Trophy className="w-4 h-4" />
              </div>
              <div className="text-2xl font-bold text-yellow-600">{profile.achievements}</div>
              <div className="text-xs text-muted-foreground">Achievements</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Learning Preferences */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-lg">Learning Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isEditing ? (
            <>
              <div>
                <Label htmlFor="learningGoal" className="text-sm font-medium">
                  Learning Goal
                </Label>
                <Select
                  value={profile.learningGoal}
                  onValueChange={(value) => setProfile({ ...profile, learningGoal: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner - Just getting started</SelectItem>
                    <SelectItem value="intermediate">Intermediate - Building skills</SelectItem>
                    <SelectItem value="advanced">Advanced - Mastering techniques</SelectItem>
                    <SelectItem value="professional">Professional - Career focused</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="dailyGoal" className="text-sm font-medium">
                  Daily Lesson Goal
                </Label>
                <Select
                  value={profile.dailyGoal.toString()}
                  onValueChange={(value) => setProfile({ ...profile, dailyGoal: Number.parseInt(value) })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 lesson per day</SelectItem>
                    <SelectItem value="3">3 lessons per day</SelectItem>
                    <SelectItem value="5">5 lessons per day</SelectItem>
                    <SelectItem value="10">10 lessons per day</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          ) : (
            <>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Learning Level</span>
                <Badge variant="outline" className="capitalize">
                  {profile.learningGoal}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Daily Goal</span>
                <Badge variant="outline">{profile.dailyGoal} lessons/day</Badge>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-lg">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start bg-transparent">
            Share Progress
          </Button>
          <Button variant="outline" className="w-full justify-start bg-transparent">
            Download Certificate
          </Button>
          <Button variant="outline" className="w-full justify-start bg-transparent">
            Export Learning Data
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
