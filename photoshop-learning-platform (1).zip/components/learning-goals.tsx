"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Target, Plus, CheckCircle } from "lucide-react"

const goals = [
  {
    id: 1,
    title: "Master Selection Tools",
    description: "Complete all selection tool lessons",
    progress: 80,
    target: 100,
    deadline: "Feb 15",
    priority: "high",
    completed: false,
  },
  {
    id: 2,
    title: "Create 5 Digital Art Pieces",
    description: "Apply learned skills in creative projects",
    progress: 60,
    target: 100,
    deadline: "Feb 28",
    priority: "medium",
    completed: false,
  },
  {
    id: 3,
    title: "Learn Layer Techniques",
    description: "Master advanced layer manipulation",
    progress: 100,
    target: 100,
    deadline: "Feb 1",
    priority: "high",
    completed: true,
  },
]

export function LearningGoals() {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="font-heading text-lg flex items-center gap-2">
            <Target className="w-5 h-5 text-green-600" />
            Learning Goals
          </CardTitle>
          <Button variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Add Goal
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {goals.map((goal) => (
            <div
              key={goal.id}
              className={`p-4 rounded-lg border ${
                goal.completed ? "bg-green-50 border-green-200" : "bg-gray-50 border-gray-200"
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-semibold text-sm">{goal.title}</h4>
                      {goal.completed && <CheckCircle className="w-4 h-4 text-green-600" />}
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{goal.description}</p>
                    <div className="flex items-center gap-2">
                      <Badge
                        variant={
                          goal.priority === "high"
                            ? "destructive"
                            : goal.priority === "medium"
                              ? "default"
                              : "secondary"
                        }
                        className="text-xs"
                      >
                        {goal.priority} priority
                      </Badge>
                      <span className="text-xs text-muted-foreground">Due: {goal.deadline}</span>
                    </div>
                  </div>
                </div>

                {!goal.completed && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Progress</span>
                      <span>{goal.progress}%</span>
                    </div>
                    <Progress value={goal.progress} className="h-2" />
                  </div>
                )}

                {goal.completed && (
                  <div className="flex items-center gap-2 text-green-600 text-xs">
                    <CheckCircle className="w-3 h-3" />
                    Goal Completed!
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
