import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Trophy, Flame, Gem, BarChart3, Award, Settings } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export function Header() {
  return (
    <header className="bg-background border-b border-border shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <h1 className="font-heading text-2xl font-bold text-cyan-800 dark:text-cyan-400">PhotoShop Academy</h1>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Courses
            </Link>
            <Link href="/dashboard" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Dashboard
            </Link>
            <Link href="/missions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Missions
            </Link>
            <Link href="/achievements" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Achievements
            </Link>
            <Link href="/profile" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Profile
            </Link>
          </nav>

          <div className="flex items-center gap-6">
            {/* Stats */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-orange-500" />
                <span className="font-semibold text-orange-600 dark:text-orange-400">7</span>
              </div>
              <div className="flex items-center gap-2">
                <Gem className="w-5 h-5 text-blue-500" />
                <span className="font-semibold text-blue-600 dark:text-blue-400">1,250</span>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span className="font-semibold text-yellow-600 dark:text-yellow-400">12</span>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/dashboard">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Dashboard
                </Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link href="/missions">
                  <Award className="w-4 h-4 mr-2" />
                  Missions
                </Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link href="/settings">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Link>
              </Button>
              <ThemeToggle />
            </div>

            {/* Profile Avatar */}
            <Link href="/profile">
              <Avatar className="w-10 h-10 cursor-pointer hover:ring-2 hover:ring-cyan-500 transition-all">
                <AvatarImage src="/diverse-user-avatars.png" />
                <AvatarFallback className="bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200">
                  JD
                </AvatarFallback>
              </Avatar>
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}
