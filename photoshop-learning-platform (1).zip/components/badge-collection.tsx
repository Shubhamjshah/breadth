"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Trophy, Star, Flame, Target, Zap, Award, Share2 } from "lucide-react"
import { cn } from "@/lib/utils"

const unlockedBadges = [
  {
    id: 1,
    name: "First Steps",
    icon: Star,
    color: "bg-blue-500",
    rarity: "common",
    unlockedDate: "2024-01-15",
  },
  {
    id: 2,
    name: "Lesson Master",
    icon: Trophy,
    color: "bg-green-500",
    rarity: "uncommon",
    unlockedDate: "2024-02-01",
  },
  {
    id: 3,
    name: "Week Warrior",
    icon: Flame,
    color: "bg-orange-500",
    rarity: "uncommon",
    unlockedDate: "2024-02-05",
  },
  {
    id: 4,
    name: "Layer Wizard",
    icon: Zap,
    color: "bg-indigo-500",
    rarity: "uncommon",
    unlockedDate: "2024-02-03",
  },
  {
    id: 5,
    name: "Speed Demon",
    icon: Target,
    color: "bg-lime-500",
    rarity: "uncommon",
    unlockedDate: "2024-01-28",
  },
  {
    id: 6,
    name: "Consistent Learner",
    icon: Award,
    color: "bg-purple-500",
    rarity: "common",
    unlockedDate: "2024-01-20",
  },
]

const rarityColors = {
  common: "border-gray-300",
  uncommon: "border-green-300",
  rare: "border-blue-300",
  epic: "border-purple-300",
  legendary: "border-yellow-300",
}

export function BadgeCollection() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="font-heading text-lg">Badge Collection</CardTitle>
            <Badge variant="secondary">{unlockedBadges.length} badges</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            {unlockedBadges.map((badge) => {
              const Icon = badge.icon
              return (
                <div
                  key={badge.id}
                  className={cn(
                    "relative group cursor-pointer transition-all duration-200 hover:scale-105",
                    "p-3 rounded-lg border-2",
                    rarityColors[badge.rarity as keyof typeof rarityColors],
                  )}
                >
                  <div className={cn("w-12 h-12 rounded-full flex items-center justify-center mx-auto", badge.color)}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <p className="text-xs text-center mt-2 font-medium truncate">{badge.name}</p>

                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-black text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                    Unlocked: {badge.unlockedDate}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-lg">Featured Badge</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center space-y-4">
            <div className="w-20 h-20 bg-gradient-to-r from-orange-400 to-red-500 rounded-full flex items-center justify-center mx-auto">
              <Flame className="w-10 h-10 text-white" />
            </div>
            <div>
              <h3 className="font-heading text-lg font-semibold">Week Warrior</h3>
              <p className="text-sm text-muted-foreground">Your most recent achievement</p>
              <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200 mt-2">Uncommon</Badge>
            </div>
            <Button variant="outline" className="w-full bg-transparent">
              <Share2 className="w-4 h-4 mr-2" />
              Share Badge
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading text-lg">Next Milestone</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-3">
                <Trophy className="w-8 h-8 text-gray-400" />
              </div>
              <h4 className="font-semibold">Knowledge Seeker</h4>
              <p className="text-xs text-muted-foreground">Complete 50 lessons</p>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span className="text-muted-foreground">26/50</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: "52%" }} />
              </div>
            </div>
            <p className="text-xs text-center text-muted-foreground">24 more lessons to unlock this rare badge!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
