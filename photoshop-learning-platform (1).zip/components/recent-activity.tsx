"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, Play, Trophy, Star, CheckCircle } from "lucide-react"

const activities = [
  {
    id: 1,
    type: "lesson_completed",
    title: "Completed 'Tools Panel'",
    description: "Photoshop Basics • Lesson 2",
    time: "2 hours ago",
    xp: 75,
    icon: CheckCircle,
    color: "text-green-600",
  },
  {
    id: 2,
    type: "achievement_unlocked",
    title: "Unlocked 'Week Warrior'",
    description: "Complete 7 days in a row",
    time: "1 day ago",
    xp: 100,
    icon: Trophy,
    color: "text-yellow-600",
  },
  {
    id: 3,
    type: "lesson_started",
    title: "Started 'Magic Wand Tool'",
    description: "Selection Tools • Lesson 3",
    time: "1 day ago",
    xp: 0,
    icon: Play,
    color: "text-blue-600",
  },
  {
    id: 4,
    type: "perfect_score",
    title: "Perfect Quiz Score",
    description: "100% on Layers Basics quiz",
    time: "2 days ago",
    xp: 50,
    icon: Star,
    color: "text-purple-600",
  },
  {
    id: 5,
    type: "lesson_completed",
    title: "Completed 'Layers Basics'",
    description: "Photoshop Basics • Lesson 3",
    time: "2 days ago",
    xp: 75,
    icon: CheckCircle,
    color: "text-green-600",
  },
]

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Activity className="w-5 h-5 text-blue-600" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const Icon = activity.icon
            return (
              <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-8 h-8 rounded-full bg-white flex items-center justify-center ${activity.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{activity.title}</p>
                  <p className="text-xs text-muted-foreground">{activity.description}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-muted-foreground">{activity.time}</span>
                    {activity.xp > 0 && (
                      <Badge variant="secondary" className="text-xs">
                        +{activity.xp} XP
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
