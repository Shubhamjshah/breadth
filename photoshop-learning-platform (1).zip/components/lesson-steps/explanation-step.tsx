"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import Image from "next/image"

interface ExplanationStepProps {
  step: {
    title: string
    content: string
    image?: string
  }
  onComplete: () => void
  isCompleted: boolean
}

export function ExplanationStep({ step, onComplete, isCompleted }: ExplanationStepProps) {
  const [hasRead, setHasRead] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setHasRead(true)
    }, 3000) // Auto-mark as read after 3 seconds

    return () => clearTimeout(timer)
  }, [])

  const handleContinue = () => {
    onComplete()
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="font-heading text-2xl font-bold mb-4">{step.title}</h2>
        {step.image && (
          <div className="mb-6">
            <Image
              src={step.image || "/placeholder.svg"}
              alt={step.title}
              width={500}
              height={300}
              className="mx-auto rounded-lg shadow-md"
            />
          </div>
        )}
        <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">{step.content}</p>
      </div>

      <div className="flex justify-center">
        <Button onClick={handleContinue} disabled={!hasRead && !isCompleted} className="bg-lime-600 hover:bg-lime-700">
          {isCompleted ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Completed
            </>
          ) : (
            "Continue"
          )}
        </Button>
      </div>
    </div>
  )
}
