"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"
import Image from "next/image"

interface InteractiveStepProps {
  step: {
    title: string
    content: string
    activity: string
    image: string
    hotspots?: Array<{ x: number; y: number; correct: boolean }>
  }
  onComplete: () => void
  isCompleted: boolean
}

export function InteractiveStep({ step, onComplete, isCompleted }: InteractiveStepProps) {
  const [clicked, setClicked] = useState(false)
  const [clickPosition, setClickPosition] = useState<{ x: number; y: number } | null>(null)

  const handleImageClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    const x = event.clientX - rect.left
    const y = event.clientY - rect.top

    setClickPosition({ x, y })
    setClicked(true)

    // Check if click is near any hotspot
    if (step.hotspots) {
      const isCorrect = step.hotspots.some((hotspot) => {
        const distance = Math.sqrt(Math.pow(x - hotspot.x, 2) + Math.pow(y - hotspot.y, 2))
        return distance < 30 && hotspot.correct
      })

      if (isCorrect) {
        setTimeout(() => {
          onComplete()
        }, 1000)
      }
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="font-heading text-2xl font-bold mb-4">{step.title}</h2>
        <p className="text-lg text-muted-foreground mb-6">{step.content}</p>
      </div>

      <div className="relative max-w-2xl mx-auto">
        <div className="relative cursor-crosshair" onClick={handleImageClick}>
          <Image
            src={step.image || "/placeholder.svg"}
            alt={step.title}
            width={500}
            height={300}
            className="w-full rounded-lg shadow-md"
          />

          {/* Show click position */}
          {clickPosition && (
            <div
              className="absolute w-6 h-6 bg-cyan-500 rounded-full border-2 border-white shadow-lg transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: clickPosition.x, top: clickPosition.y }}
            />
          )}

          {/* Show correct hotspots after completion */}
          {isCompleted &&
            step.hotspots?.map((hotspot, index) => (
              <div
                key={index}
                className="absolute w-8 h-8 bg-green-500 rounded-full border-2 border-white shadow-lg transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
                style={{ left: hotspot.x, top: hotspot.y }}
              >
                <CheckCircle className="w-4 h-4 text-white" />
              </div>
            ))}
        </div>
      </div>

      {isCompleted && (
        <div className="text-center">
          <Button disabled className="bg-green-600">
            <CheckCircle className="w-4 h-4 mr-2" />
            Great Job!
          </Button>
        </div>
      )}
    </div>
  )
}
