"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, ExternalLink } from "lucide-react"

interface PracticeStepProps {
  step: {
    title: string
    content: string
    task: string
  }
  onComplete: () => void
  isCompleted: boolean
}

export function PracticeStep({ step, onComplete, isCompleted }: PracticeStepProps) {
  const [notes, setNotes] = useState("")
  const [completed, setCompleted] = useState(false)

  const handleComplete = () => {
    setCompleted(true)
    onComplete()
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="font-heading text-2xl font-bold mb-4">{step.title}</h2>
        <p className="text-lg text-muted-foreground mb-6">{step.content}</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-4">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-semibold text-blue-900 mb-2">Your Task:</h3>
          <p className="text-blue-800">{step.task}</p>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Notes (optional):</label>
          <Textarea
            placeholder="Write down what you learned or any questions you have..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="min-h-[100px]"
          />
        </div>

        <div className="bg-gray-50 border rounded-lg p-4">
          <p className="text-sm text-gray-600 mb-3">Need help? Check out these resources:</p>
          <div className="space-y-2">
            <a href="#" className="flex items-center gap-2 text-cyan-600 hover:text-cyan-700 text-sm">
              <ExternalLink className="w-4 h-4" />
              Photoshop Help: Working with Panels
            </a>
            <a href="#" className="flex items-center gap-2 text-cyan-600 hover:text-cyan-700 text-sm">
              <ExternalLink className="w-4 h-4" />
              Video Tutorial: Interface Basics
            </a>
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <Button onClick={handleComplete} disabled={completed} className="bg-lime-600 hover:bg-lime-700">
          {completed || isCompleted ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Completed
            </>
          ) : (
            "Mark as Complete"
          )}
        </Button>
      </div>
    </div>
  )
}
