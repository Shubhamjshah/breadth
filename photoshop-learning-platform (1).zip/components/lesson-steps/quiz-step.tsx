"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface QuizStepProps {
  step: {
    title: string
    question: string
    options: string[]
    correct: number
  }
  onComplete: () => void
  isCompleted: boolean
}

export function QuizStep({ step, onComplete, isCompleted }: QuizStepProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)

  const handleSubmit = () => {
    if (selectedOption !== null) {
      setShowResult(true)
      if (selectedOption === step.correct) {
        setTimeout(() => {
          onComplete()
        }, 1500)
      }
    }
  }

  const handleRetry = () => {
    setSelectedOption(null)
    setShowResult(false)
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="font-heading text-2xl font-bold mb-4">{step.title}</h2>
        <p className="text-lg mb-6">{step.question}</p>
      </div>

      <div className="space-y-3 max-w-2xl mx-auto">
        {step.options.map((option, index) => (
          <Card
            key={index}
            className={cn(
              "cursor-pointer transition-all duration-200",
              selectedOption === index && "ring-2 ring-cyan-500",
              showResult && index === step.correct && "bg-green-50 border-green-500",
              showResult && selectedOption === index && index !== step.correct && "bg-red-50 border-red-500",
            )}
            onClick={() => !showResult && setSelectedOption(index)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {showResult && index === step.correct && <CheckCircle className="w-5 h-5 text-green-600" />}
                {showResult && selectedOption === index && index !== step.correct && (
                  <X className="w-5 h-5 text-red-600" />
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-center gap-4">
        {!showResult ? (
          <Button onClick={handleSubmit} disabled={selectedOption === null} className="bg-cyan-600 hover:bg-cyan-700">
            Submit Answer
          </Button>
        ) : selectedOption === step.correct ? (
          <Button disabled className="bg-green-600">
            <CheckCircle className="w-4 h-4 mr-2" />
            Correct!
          </Button>
        ) : (
          <Button onClick={handleRetry} variant="outline">
            Try Again
          </Button>
        )}
      </div>
    </div>
  )
}
