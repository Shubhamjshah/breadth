"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, Trophy, ArrowRight, Award } from "lucide-react"
import Link from "next/link"

interface CompletionStepProps {
  step: {
    title: string
    content: string
    xpGained: number
  }
  onComplete: () => void
  isCompleted: boolean
}

export function CompletionStep({ step, onComplete, isCompleted }: CompletionStepProps) {
  const [showAnimation, setShowAnimation] = useState(false)
  const [showAchievement, setShowAchievement] = useState(false)

  useEffect(() => {
    setShowAnimation(true)
    onComplete()

    setTimeout(() => {
      setShowAchievement(true)
    }, 2000)
  }, [onComplete])

  return (
    <div className="space-y-8 text-center">
      <div className={`transition-all duration-1000 ${showAnimation ? "scale-100 opacity-100" : "scale-75 opacity-0"}`}>
        <div className="w-24 h-24 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6">
          <Trophy className="w-12 h-12 text-white" />
        </div>

        <h2 className="font-heading text-3xl font-bold mb-4">{step.title}</h2>
        <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">{step.content}</p>

        <div className="flex items-center justify-center gap-4 mb-8">
          <Badge className="bg-lime-100 text-lime-800 hover:bg-lime-200 text-lg px-4 py-2">
            <Star className="w-5 h-5 mr-2" />+{step.xpGained} XP
          </Badge>
        </div>

        <div className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-600">1</div>
              <div className="text-sm text-blue-800">Lesson Completed</div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">7</div>
              <div className="text-sm text-green-800">Day Streak</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-600">1,325</div>
              <div className="text-sm text-purple-800">Total XP</div>
            </div>
          </div>
        </div>
      </div>

      {showAchievement && (
        <div className="fixed top-4 right-4 bg-white border border-green-200 rounded-lg shadow-lg p-4 max-w-sm animate-in slide-in-from-right z-50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="font-semibold text-sm">Achievement Unlocked!</p>
              <p className="text-xs text-muted-foreground">First Steps - Complete your first lesson</p>
              <Badge className="bg-green-100 text-green-800 hover:bg-green-200 text-xs mt-1">+25 XP</Badge>
            </div>
          </div>
        </div>
      )}

      <div className="flex gap-4 justify-center">
        <Button variant="outline" asChild>
          <Link href="/">Back to Courses</Link>
        </Button>
        <Button className="bg-cyan-600 hover:bg-cyan-700" asChild>
          <Link href="/lesson/2">
            Next Lesson
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </Button>
      </div>
    </div>
  )
}
