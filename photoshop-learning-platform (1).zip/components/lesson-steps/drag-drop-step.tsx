"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface DragDropStepProps {
  step: {
    title: string
    content: string
    items: Array<{ id: string; name: string; category: string }>
    categories: string[]
  }
  onComplete: () => void
  isCompleted: boolean
}

export function DragDropStep({ step, onComplete, isCompleted }: DragDropStepProps) {
  const [draggedItem, setDraggedItem] = useState<string | null>(null)
  const [placements, setPlacements] = useState<Record<string, string>>({})
  const [showResult, setShowResult] = useState(false)

  const handleDragStart = (itemId: string) => {
    setDraggedItem(itemId)
  }

  const handleDrop = (category: string) => {
    if (draggedItem) {
      setPlacements((prev) => ({ ...prev, [draggedItem]: category }))
      setDraggedItem(null)
    }
  }

  const handleCheck = () => {
    setShowResult(true)
    const allCorrect = step.items.every((item) => placements[item.id] === item.category)
    if (allCorrect) {
      setTimeout(() => {
        onComplete()
      }, 1500)
    }
  }

  const isCorrectPlacement = (itemId: string) => {
    const item = step.items.find((i) => i.id === itemId)
    return item && placements[itemId] === item.category
  }

  const allItemsPlaced = step.items.every((item) => placements[item.id])

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="font-heading text-2xl font-bold mb-4">{step.title}</h2>
        <p className="text-lg text-muted-foreground mb-6">{step.content}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {/* Items to drag */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Tools</h3>
          <div className="space-y-2">
            {step.items
              .filter((item) => !placements[item.id])
              .map((item) => (
                <Card
                  key={item.id}
                  className="cursor-move hover:shadow-md transition-shadow"
                  draggable
                  onDragStart={() => handleDragStart(item.id)}
                >
                  <CardContent className="p-3">
                    <span className="font-medium">{item.name}</span>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>

        {/* Drop zones */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Categories</h3>
          <div className="space-y-3">
            {step.categories.map((category) => (
              <Card
                key={category}
                className={cn(
                  "min-h-[100px] border-2 border-dashed transition-colors",
                  draggedItem && "border-cyan-400 bg-cyan-50",
                )}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => handleDrop(category)}
              >
                <CardContent className="p-4">
                  <h4 className="font-medium capitalize mb-2">{category}</h4>
                  <div className="space-y-2">
                    {step.items
                      .filter((item) => placements[item.id] === category)
                      .map((item) => (
                        <div
                          key={item.id}
                          className={cn(
                            "p-2 bg-gray-100 rounded text-sm",
                            showResult && isCorrectPlacement(item.id) && "bg-green-100 border border-green-300",
                            showResult && !isCorrectPlacement(item.id) && "bg-red-100 border border-red-300",
                          )}
                        >
                          {item.name}
                          {showResult && isCorrectPlacement(item.id) && (
                            <CheckCircle className="w-4 h-4 text-green-600 inline ml-2" />
                          )}
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        {!showResult ? (
          <Button onClick={handleCheck} disabled={!allItemsPlaced} className="bg-cyan-600 hover:bg-cyan-700">
            Check Answers
          </Button>
        ) : (
          <Button disabled className="bg-green-600">
            <CheckCircle className="w-4 h-4 mr-2" />
            {step.items.every((item) => isCorrectPlacement(item.id)) ? "Perfect!" : "Keep Learning!"}
          </Button>
        )}
      </div>
    </div>
  )
}
