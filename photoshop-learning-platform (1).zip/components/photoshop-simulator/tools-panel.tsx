"use client"

import { Button } from "@/components/ui/button"

const tools = [
  { id: "move", name: "Move Tool", icon: "↖", cursor: "move" },
  { id: "marquee", name: "Rectangular Marquee", icon: "⬚", cursor: "crosshair" },
  { id: "lasso", name: "Lasso Tool", icon: "◯", cursor: "crosshair" },
  { id: "wand", name: "Magic Wand", icon: "✨", cursor: "crosshair" },
  { id: "crop", name: "Crop Tool", icon: "⚏", cursor: "crosshair" },
  { id: "eyedropper", name: "Eyedropper", icon: "💧", cursor: "crosshair" },
  { id: "healing", name: "Healing Brush", icon: "🩹", cursor: "crosshair" },
  { id: "brush", name: "Brush Tool", icon: "🖌", cursor: "crosshair" },
  { id: "clone", name: "Clone Stamp", icon: "📋", cursor: "crosshair" },
  { id: "eraser", name: "Eraser", icon: "🧽", cursor: "crosshair" },
  { id: "gradient", name: "Gradient Tool", icon: "📐", cursor: "crosshair" },
  { id: "blur", name: "Blur Tool", icon: "💫", cursor: "crosshair" },
  { id: "dodge", name: "Dodge Tool", icon: "☀", cursor: "crosshair" },
  { id: "pen", name: "Pen Tool", icon: "✒", cursor: "crosshair" },
  { id: "text", name: "Type Tool", icon: "T", cursor: "text" },
  { id: "shape", name: "Rectangle Tool", icon: "▭", cursor: "crosshair" },
]

interface ToolsPanelProps {
  selectedTool: string
  onToolSelect: (toolId: string) => void
}

export function ToolsPanel({ selectedTool, onToolSelect }: ToolsPanelProps) {
  return (
    <div className="p-2 space-y-1">
      {tools.map((tool) => (
        <Button
          key={tool.id}
          variant={selectedTool === tool.id ? "default" : "ghost"}
          size="sm"
          className="w-12 h-12 p-0 text-lg"
          onClick={() => onToolSelect(tool.id)}
          title={tool.name}
        >
          {tool.icon}
        </Button>
      ))}
    </div>
  )
}
