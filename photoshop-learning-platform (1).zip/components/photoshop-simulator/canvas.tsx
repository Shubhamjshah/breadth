"use client"

import type React from "react"

import { forwardRef, useEffect, useRef, useState } from "react"
import type { PhotoshopState } from "./photoshop-interface"

interface CanvasProps {
  state: PhotoshopState
  onStateChange: (updates: Partial<PhotoshopState>) => void
  tutorialTarget?: string
}

export const Canvas = forwardRef<HTMLCanvasElement, CanvasProps>(({ state, onStateChange, tutorialTarget }, ref) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [selectedObject, setSelectedObject] = useState<string | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas size based on zoom
    const scale = state.zoom / 100
    ctx.save()
    ctx.scale(scale, scale)

    // Draw checkerboard background
    drawCheckerboard(ctx, state.canvasSize.width, state.canvasSize.height)

    // Draw layers
    state.layers.forEach((layer) => {
      if (!layer.visible) return

      ctx.save()
      ctx.globalAlpha = layer.opacity / 100

      // Set blend mode
      ctx.globalCompositeOperation = layer.blendMode as GlobalCompositeOperation

      if (layer.type === "background") {
        ctx.fillStyle = "#ffffff"
        ctx.fillRect(0, 0, state.canvasSize.width, state.canvasSize.height)
      } else {
        // Draw layer content
        ctx.fillStyle = layer.id === state.activeLayer ? "#4f46e5" : "#6b7280"
        ctx.fillRect(layer.position.x, layer.position.y, layer.size.width, layer.size.height)

        // Draw selection outline for active layer
        if (layer.id === state.activeLayer) {
          ctx.strokeStyle = "#3b82f6"
          ctx.lineWidth = 2 / scale
          ctx.setLineDash([5 / scale, 5 / scale])
          ctx.strokeRect(layer.position.x, layer.position.y, layer.size.width, layer.size.height)
          ctx.setLineDash([])
        }
      }

      ctx.restore()
    })

    ctx.restore()

    // Highlight tutorial target
    if (tutorialTarget) {
      highlightTutorialTarget(ctx, tutorialTarget, scale)
    }
  }, [state, tutorialTarget])

  const drawCheckerboard = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    const squareSize = 20
    ctx.fillStyle = "#f0f0f0"
    ctx.fillRect(0, 0, width, height)

    ctx.fillStyle = "#e0e0e0"
    for (let x = 0; x < width; x += squareSize) {
      for (let y = 0; y < height; y += squareSize) {
        if ((x / squareSize + y / squareSize) % 2 === 0) {
          ctx.fillRect(x, y, squareSize, squareSize)
        }
      }
    }
  }

  const highlightTutorialTarget = (ctx: CanvasRenderingContext2D, target: string, scale: number) => {
    // Highlight specific areas based on tutorial target
    ctx.save()
    ctx.strokeStyle = "#fbbf24"
    ctx.lineWidth = 3 / scale
    ctx.setLineDash([10 / scale, 5 / scale])

    if (target === "active-layer") {
      const activeLayer = state.layers.find((l) => l.id === state.activeLayer)
      if (activeLayer) {
        ctx.strokeRect(
          activeLayer.position.x - 10,
          activeLayer.position.y - 10,
          activeLayer.size.width + 20,
          activeLayer.size.height + 20,
        )
      }
    }

    ctx.restore()
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const scale = state.zoom / 100
    const x = (e.clientX - rect.left) / scale
    const y = (e.clientY - rect.top) / scale

    if (state.selectedTool === "move") {
      // Check if clicking on a layer
      const clickedLayer = state.layers
        .slice()
        .reverse()
        .find((layer) => {
          return (
            layer.visible &&
            x >= layer.position.x &&
            x <= layer.position.x + layer.size.width &&
            y >= layer.position.y &&
            y <= layer.position.y + layer.size.height
          )
        })

      if (clickedLayer) {
        onStateChange({ activeLayer: clickedLayer.id })
        setSelectedObject(clickedLayer.id)
        setIsDragging(true)
        setDragStart({ x: x - clickedLayer.position.x, y: y - clickedLayer.position.y })
      }
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !selectedObject) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const scale = state.zoom / 100
    const x = (e.clientX - rect.left) / scale
    const y = (e.clientY - rect.top) / scale

    const newPosition = {
      x: x - dragStart.x,
      y: y - dragStart.y,
    }

    const updatedLayers = state.layers.map((layer) =>
      layer.id === selectedObject ? { ...layer, position: newPosition } : layer,
    )

    onStateChange({ layers: updatedLayers })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    setSelectedObject(null)
  }

  return (
    <div className="w-full h-full flex items-center justify-center overflow-auto">
      <canvas
        ref={(node) => {
          canvasRef.current = node
          if (typeof ref === "function") {
            ref(node)
          } else if (ref) {
            ref.current = node
          }
        }}
        width={state.canvasSize.width * (state.zoom / 100)}
        height={state.canvasSize.height * (state.zoom / 100)}
        className="border border-gray-400 bg-white cursor-crosshair"
        style={{
          cursor: state.selectedTool === "move" ? "move" : "crosshair",
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
    </div>
  )
})

Canvas.displayName = "Canvas"
