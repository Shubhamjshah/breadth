"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ToolsPanel } from "./tools-panel"
import { LayersPanel } from "./layers-panel"
import { Canvas } from "./canvas"
import { PropertiesPanel } from "./properties-panel"
import { TutorialOverlay } from "./tutorial-overlay"

export interface Layer {
  id: string
  name: string
  visible: boolean
  opacity: number
  blendMode: string
  type: "background" | "layer" | "text"
  content?: string
  position: { x: number; y: number }
  size: { width: number; height: number }
}

export interface Tool {
  id: string
  name: string
  icon: string
  cursor: string
  properties?: Record<string, any>
}

export interface PhotoshopState {
  selectedTool: string
  layers: Layer[]
  activeLayer: string
  zoom: number
  canvasSize: { width: number; height: number }
  history: any[]
  historyIndex: number
}

interface PhotoshopInterfaceProps {
  tutorialStep?: {
    id: string
    title: string
    instruction: string
    target?: string
    validation?: (state: PhotoshopState) => boolean
  }
  onStepComplete?: () => void
  onStateChange?: (state: PhotoshopState) => void
}

export function PhotoshopInterface({ tutorialStep, onStepComplete, onStateChange }: PhotoshopInterfaceProps) {
  const [state, setState] = useState<PhotoshopState>({
    selectedTool: "move",
    layers: [
      {
        id: "background",
        name: "Background",
        visible: true,
        opacity: 100,
        blendMode: "normal",
        type: "background",
        position: { x: 0, y: 0 },
        size: { width: 800, height: 600 },
      },
      {
        id: "layer1",
        name: "Layer 1",
        visible: true,
        opacity: 100,
        blendMode: "normal",
        type: "layer",
        position: { x: 100, y: 100 },
        size: { width: 200, height: 150 },
      },
    ],
    activeLayer: "layer1",
    zoom: 100,
    canvasSize: { width: 800, height: 600 },
    history: [],
    historyIndex: -1,
  })

  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    onStateChange?.(state)
  }, [state, onStateChange])

  const updateState = (updates: Partial<PhotoshopState>) => {
    setState((prev) => ({ ...prev, ...updates }))
  }

  const selectTool = (toolId: string) => {
    updateState({ selectedTool: toolId })
  }

  const updateLayer = (layerId: string, updates: Partial<Layer>) => {
    const updatedLayers = state.layers.map((layer) => (layer.id === layerId ? { ...layer, ...updates } : layer))
    updateState({ layers: updatedLayers })
  }

  const addLayer = (layer: Omit<Layer, "id">) => {
    const newLayer: Layer = {
      ...layer,
      id: `layer_${Date.now()}`,
    }
    updateState({
      layers: [...state.layers, newLayer],
      activeLayer: newLayer.id,
    })
  }

  const deleteLayer = (layerId: string) => {
    if (state.layers.length <= 1) return
    const filteredLayers = state.layers.filter((layer) => layer.id !== layerId)
    const newActiveLayer = filteredLayers[filteredLayers.length - 1]?.id || filteredLayers[0]?.id
    updateState({
      layers: filteredLayers,
      activeLayer: newActiveLayer,
    })
  }

  const setZoom = (zoom: number) => {
    updateState({ zoom: Math.max(25, Math.min(800, zoom)) })
  }

  // Check tutorial step validation
  useEffect(() => {
    if (tutorialStep?.validation && tutorialStep.validation(state)) {
      onStepComplete?.()
    }
  }, [state, tutorialStep, onStepComplete])

  return (
    <div className="h-screen bg-gray-800 text-white flex flex-col">
      {/* Menu Bar */}
      <div className="bg-gray-900 border-b border-gray-700 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span className="font-semibold">Photoshop Simulator</span>
          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <span>File</span>
            <span>Edit</span>
            <span>Image</span>
            <span>Layer</span>
            <span>Select</span>
            <span>Filter</span>
            <span>View</span>
            <span>Window</span>
            <span>Help</span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm" onClick={() => setZoom(state.zoom - 25)}>
            -
          </Button>
          <span className="text-sm w-12 text-center">{state.zoom}%</span>
          <Button variant="ghost" size="sm" onClick={() => setZoom(state.zoom + 25)}>
            +
          </Button>
        </div>
      </div>

      {/* Main Interface */}
      <div className="flex-1 flex">
        {/* Tools Panel */}
        <div className="w-16 bg-gray-900 border-r border-gray-700">
          <ToolsPanel selectedTool={state.selectedTool} onToolSelect={selectTool} />
        </div>

        {/* Properties Panel */}
        <div className="w-64 bg-gray-800 border-r border-gray-700">
          <PropertiesPanel selectedTool={state.selectedTool} />
        </div>

        {/* Canvas Area */}
        <div className="flex-1 bg-gray-600 relative overflow-hidden">
          <Canvas ref={canvasRef} state={state} onStateChange={updateState} tutorialTarget={tutorialStep?.target} />
          {tutorialStep && <TutorialOverlay step={tutorialStep} />}
        </div>

        {/* Layers Panel */}
        <div className="w-80 bg-gray-800 border-l border-gray-700">
          <LayersPanel
            layers={state.layers}
            activeLayer={state.activeLayer}
            onLayerSelect={(layerId) => updateState({ activeLayer: layerId })}
            onLayerUpdate={updateLayer}
            onLayerAdd={addLayer}
            onLayerDelete={deleteLayer}
          />
        </div>
      </div>
    </div>
  )
}
