"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Layer } from "./photoshop-interface"

interface LayersPanelProps {
  layers: Layer[]
  activeLayer: string
  onLayerSelect: (layerId: string) => void
  onLayerUpdate: (layerId: string, updates: Partial<Layer>) => void
  onLayerAdd: (layer: Omit<Layer, "id">) => void
  onLayerDelete: (layerId: string) => void
}

export function LayersPanel({
  layers,
  activeLayer,
  onLayerSelect,
  onLayerUpdate,
  onLayerAdd,
  onLayerDelete,
}: LayersPanelProps) {
  const [newLayerName, setNewLayerName] = useState("")

  const addNewLayer = () => {
    const name = newLayerName || `Layer ${layers.length}`
    onLayerAdd({
      name,
      visible: true,
      opacity: 100,
      blendMode: "normal",
      type: "layer",
      position: { x: 50, y: 50 },
      size: { width: 200, height: 150 },
    })
    setNewLayerName("")
  }

  return (
    <Card className="h-full bg-gray-800 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-200">Layers</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Blend Mode and Opacity */}
        <div className="space-y-2">
          <Select
            value={layers.find((l) => l.id === activeLayer)?.blendMode || "normal"}
            onValueChange={(value) => onLayerUpdate(activeLayer, { blendMode: value })}
          >
            <SelectTrigger className="bg-gray-700 border-gray-600">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="multiply">Multiply</SelectItem>
              <SelectItem value="screen">Screen</SelectItem>
              <SelectItem value="overlay">Overlay</SelectItem>
              <SelectItem value="soft-light">Soft Light</SelectItem>
              <SelectItem value="hard-light">Hard Light</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-gray-400 w-16">Opacity:</span>
            <Slider
              value={[layers.find((l) => l.id === activeLayer)?.opacity || 100]}
              onValueChange={([value]) => onLayerUpdate(activeLayer, { opacity: value })}
              max={100}
              step={1}
              className="flex-1"
            />
            <span className="text-xs text-gray-400 w-8">
              {layers.find((l) => l.id === activeLayer)?.opacity || 100}%
            </span>
          </div>
        </div>

        {/* Layers List */}
        <div className="space-y-1 max-h-96 overflow-y-auto">
          {[...layers].reverse().map((layer) => (
            <div
              key={layer.id}
              className={`p-2 rounded cursor-pointer flex items-center space-x-2 ${
                layer.id === activeLayer ? "bg-blue-600" : "bg-gray-700 hover:bg-gray-600"
              }`}
              onClick={() => onLayerSelect(layer.id)}
            >
              <Button
                variant="ghost"
                size="sm"
                className="w-6 h-6 p-0"
                onClick={(e) => {
                  e.stopPropagation()
                  onLayerUpdate(layer.id, { visible: !layer.visible })
                }}
              >
                {layer.visible ? "👁" : "🚫"}
              </Button>
              <div className="flex-1 min-w-0">
                <div className="text-sm truncate">{layer.name}</div>
                <div className="text-xs text-gray-400">{layer.type}</div>
              </div>
              {layer.type !== "background" && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-6 h-6 p-0 text-red-400 hover:text-red-300"
                  onClick={(e) => {
                    e.stopPropagation()
                    onLayerDelete(layer.id)
                  }}
                >
                  ×
                </Button>
              )}
            </div>
          ))}
        </div>

        {/* Add Layer */}
        <div className="space-y-2 pt-2 border-t border-gray-700">
          <Input
            placeholder="New layer name"
            value={newLayerName}
            onChange={(e) => setNewLayerName(e.target.value)}
            className="bg-gray-700 border-gray-600"
            onKeyDown={(e) => e.key === "Enter" && addNewLayer()}
          />
          <Button onClick={addNewLayer} className="w-full" size="sm">
            Add Layer
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
