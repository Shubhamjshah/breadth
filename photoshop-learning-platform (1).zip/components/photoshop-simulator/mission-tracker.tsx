"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { missionDefinitions, MissionTracker } from "@/lib/missions"
import type { PhotoshopState } from "./photoshop-interface"

interface MissionTrackerProps {
  missionId?: string
  photoshopState: PhotoshopState
  onMissionComplete?: (missionId: string, xpEarned: number) => void
}

export function MissionTrackerComponent({ missionId, photoshopState, onMissionComplete }: MissionTrackerProps) {
  const [tracker] = useState(() => new MissionTracker())
  const [progress, setProgress] = useState({ completed: false, progress: 0, maxProgress: 1 })
  const [currentStep, setCurrentStep] = useState(0)

  const mission = missionId ? missionDefinitions.find((m) => m.id === missionId) : null

  useEffect(() => {
    if (!mission) return

    // Track state changes as actions
    tracker.addAction({
      type: "state_change",
      state: photoshopState,
      selectedTool: photoshopState.selectedTool,
      layerCount: photoshopState.layers.length,
    })

    // Validate mission progress
    const newProgress = tracker.validateMission(mission.id, photoshopState)
    if (newProgress) {
      setProgress(newProgress)

      // Update mission progress on server
      updateMissionProgress(mission.id, newProgress)

      // Check if mission completed
      if (newProgress.completed && !progress.completed) {
        onMissionComplete?.(mission.id, mission.xpReward)
      }
    }
  }, [photoshopState, mission, tracker])

  const updateMissionProgress = async (missionId: string, progress: any) => {
    try {
      await fetch("/api/missions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          missionId,
          progress: progress.progress,
          completed: progress.completed,
          actions: tracker["actions"], // Access private property for demo
        }),
      })
    } catch (error) {
      console.error("Failed to update mission progress:", error)
    }
  }

  const nextStep = () => {
    if (mission && currentStep < mission.instructions.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  if (!mission) return null

  const currentInstruction = mission.instructions[currentStep]

  return (
    <Card className="absolute top-4 right-4 w-80 bg-blue-900/95 border-blue-600 backdrop-blur-sm z-20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-blue-100">{mission.title}</CardTitle>
          <Badge variant="secondary" className="bg-lime-600 text-white">
            +{mission.xpReward} XP
          </Badge>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-blue-200">
            <span>Progress</span>
            <span>
              {progress.progress}/{progress.maxProgress}
            </span>
          </div>
          <Progress value={(progress.progress / progress.maxProgress) * 100} className="h-2" />
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Current Instruction */}
        <div className="bg-blue-800/50 p-3 rounded-lg">
          <h4 className="font-semibold text-blue-100 mb-2">
            Step {currentStep + 1}: {currentInstruction.title}
          </h4>
          <p className="text-blue-200 text-sm">{currentInstruction.instruction}</p>
        </div>

        {/* Step Navigation */}
        <div className="flex justify-between items-center">
          <Button variant="outline" size="sm" onClick={prevStep} disabled={currentStep === 0}>
            Previous
          </Button>
          <span className="text-xs text-blue-300">
            {currentStep + 1} of {mission.instructions.length}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={nextStep}
            disabled={currentStep === mission.instructions.length - 1}
          >
            Next
          </Button>
        </div>

        {/* Mission Status */}
        {progress.completed && (
          <div className="bg-green-600/20 border border-green-500 p-3 rounded-lg text-center">
            <div className="text-green-400 font-semibold">Mission Completed!</div>
            <div className="text-green-300 text-sm">+{mission.xpReward} XP earned</div>
          </div>
        )}

        {/* Time Tracking for Timed Missions */}
        {mission.requirements.timeLimit && (
          <div className="text-xs text-blue-300">
            Time Limit: {Math.floor(mission.requirements.timeLimit / 60)}:
            {String(mission.requirements.timeLimit % 60).padStart(2, "0")}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
