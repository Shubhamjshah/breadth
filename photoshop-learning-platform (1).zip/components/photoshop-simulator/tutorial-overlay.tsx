"use client"

import { Card, CardContent } from "@/components/ui/card"

interface TutorialStep {
  id: string
  title: string
  instruction: string
  target?: string
}

interface TutorialOverlayProps {
  step: TutorialStep
}

export function TutorialOverlay({ step }: TutorialOverlayProps) {
  return (
    <div className="absolute top-4 left-4 z-10">
      <Card className="w-80 bg-blue-900/90 border-blue-600 backdrop-blur-sm">
        <CardContent className="p-4">
          <h3 className="font-semibold text-blue-100 mb-2">{step.title}</h3>
          <p className="text-blue-200 text-sm mb-3">{step.instruction}</p>
          <div className="flex items-center justify-between">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-xs text-blue-300">Follow the highlighted area</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
