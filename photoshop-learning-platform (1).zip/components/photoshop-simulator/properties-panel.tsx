"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"

interface PropertiesPanelProps {
  selectedTool: string
}

export function PropertiesPanel({ selectedTool }: PropertiesPanelProps) {
  const getToolProperties = () => {
    switch (selectedTool) {
      case "brush":
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-2">Brush Size</label>
              <Slider defaultValue={[10]} max={100} step={1} />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Hardness</label>
              <Slider defaultValue={[100]} max={100} step={1} />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Opacity</label>
              <Slider defaultValue={[100]} max={100} step={1} />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Flow</label>
              <Slider defaultValue={[100]} max={100} step={1} />
            </div>
          </div>
        )

      case "marquee":
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-2">Feather</label>
              <Slider defaultValue={[0]} max={50} step={1} />
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Style</label>
              <Select defaultValue="normal">
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="fixed-ratio">Fixed Ratio</SelectItem>
                  <SelectItem value="fixed-size">Fixed Size</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )

      case "text":
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-2">Font Family</label>
              <Select defaultValue="arial">
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="arial">Arial</SelectItem>
                  <SelectItem value="helvetica">Helvetica</SelectItem>
                  <SelectItem value="times">Times New Roman</SelectItem>
                  <SelectItem value="courier">Courier New</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Font Size</label>
              <Slider defaultValue={[12]} max={72} min={6} step={1} />
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                B
              </Button>
              <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                I
              </Button>
              <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                U
              </Button>
            </div>
          </div>
        )

      case "gradient":
        return (
          <div className="space-y-4">
            <div>
              <label className="text-xs text-gray-400 block mb-2">Gradient Type</label>
              <Select defaultValue="linear">
                <SelectTrigger className="bg-gray-700 border-gray-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="linear">Linear</SelectItem>
                  <SelectItem value="radial">Radial</SelectItem>
                  <SelectItem value="angle">Angle</SelectItem>
                  <SelectItem value="reflected">Reflected</SelectItem>
                  <SelectItem value="diamond">Diamond</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-gray-400 block mb-2">Opacity</label>
              <Slider defaultValue={[100]} max={100} step={1} />
            </div>
          </div>
        )

      default:
        return (
          <div className="text-center text-gray-400 py-8">
            <p className="text-sm">Select a tool to view properties</p>
          </div>
        )
    }
  }

  return (
    <Card className="h-full bg-gray-800 border-gray-700">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm text-gray-200 capitalize">{selectedTool} Tool</CardTitle>
      </CardHeader>
      <CardContent>{getToolProperties()}</CardContent>
    </Card>
  )
}
