"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"
import { TrendingUp, Clock, Target, Award } from "lucide-react"

const progressData = [
  { date: "Jan 1", xp: 0, lessons: 0 },
  { date: "Jan 8", xp: 150, lessons: 3 },
  { date: "Jan 15", xp: 350, lessons: 7 },
  { date: "Jan 22", xp: 650, lessons: 13 },
  { date: "Jan 29", xp: 950, lessons: 19 },
  { date: "Feb 5", xp: 1325, lessons: 26 },
]

const skillDistribution = [
  { name: "Selection Tools", value: 25, color: "#3b82f6" },
  { name: "Layers", value: 30, color: "#10b981" },
  { name: "Color & Paint", value: 20, color: "#8b5cf6" },
  { name: "Text Tools", value: 15, color: "#f59e0b" },
  { name: "Effects", value: 10, color: "#ef4444" },
]

export function ProfileStats() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-xl">Learning Analytics</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="progress" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="progress">Progress Over Time</TabsTrigger>
            <TabsTrigger value="skills">Skill Distribution</TabsTrigger>
            <TabsTrigger value="insights">Learning Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="progress" className="space-y-4">
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    <div>
                      <p className="text-2xl font-bold">26</p>
                      <p className="text-xs text-muted-foreground">Total Lessons</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <div>
                      <p className="text-2xl font-bold">8h 45m</p>
                      <p className="text-xs text-muted-foreground">Time Spent</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-purple-600" />
                    <div>
                      <p className="text-2xl font-bold">92%</p>
                      <p className="text-xs text-muted-foreground">Avg Score</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-orange-600" />
                    <div>
                      <p className="text-2xl font-bold">7</p>
                      <p className="text-xs text-muted-foreground">Day Streak</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="xp" stroke="#3b82f6" strokeWidth={2} name="XP" />
                  <Line type="monotone" dataKey="lessons" stroke="#10b981" strokeWidth={2} name="Lessons" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-4">Skill Mastery</h3>
                <div className="space-y-4">
                  {skillDistribution.map((skill) => (
                    <div key={skill.name} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{skill.name}</span>
                        <span className="text-muted-foreground">{skill.value}%</span>
                      </div>
                      <Progress value={skill.value} className="h-2" />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-4">Learning Distribution</h3>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={skillDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {skillDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-4">
                  {skillDistribution.map((skill) => (
                    <div key={skill.name} className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: skill.color }} />
                      <span>{skill.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-lg">Learning Patterns</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Most Active Day</span>
                      <Badge variant="outline">Friday</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Preferred Time</span>
                      <Badge variant="outline">Evening</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Avg Session</span>
                      <Badge variant="outline">25 minutes</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Learning Style</span>
                      <Badge variant="outline">Visual</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-lg">Recommendations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm font-medium text-blue-900">Focus on Text Tools</p>
                    <p className="text-xs text-blue-700">
                      You're progressing well! Consider diving deeper into typography.
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="text-sm font-medium text-green-900">Maintain Your Streak</p>
                    <p className="text-xs text-green-700">Great consistency! Keep up your daily learning habit.</p>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <p className="text-sm font-medium text-purple-900">Try Advanced Challenges</p>
                    <p className="text-xs text-purple-700">
                      Ready for more complex projects? Check out advanced effects.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
