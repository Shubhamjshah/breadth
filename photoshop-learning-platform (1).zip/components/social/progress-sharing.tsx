"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Share2, Copy, Twitter, Facebook, Linkedin } from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { toast } from "sonner"

interface ProgressSharingProps {
  achievement?: {
    title: string
    description: string
    icon: string
  }
  milestone?: {
    type: "level" | "streak" | "lessons"
    value: number
  }
}

export function ProgressSharing({ achievement, milestone }: ProgressSharingProps) {
  const { user } = useAuth()
  const [isSharing, setIsSharing] = useState(false)

  const generateShareText = () => {
    if (achievement) {
      return `🎉 Just unlocked "${achievement.title}" on Photoshop Academy! ${achievement.description} #PhotoshopLearning #Achievement`
    }
    if (milestone) {
      switch (milestone.type) {
        case "level":
          return `🚀 Level ${milestone.value} reached on Photoshop Academy! My Photoshop skills are growing every day! #PhotoshopLearning #LevelUp`
        case "streak":
          return `🔥 ${milestone.value} day learning streak on Photoshop Academy! Consistency is key to mastering Photoshop! #PhotoshopLearning #Streak`
        case "lessons":
          return `📚 Completed ${milestone.value} lessons on Photoshop Academy! Every lesson brings me closer to Photoshop mastery! #PhotoshopLearning #Progress`
      }
    }
    return `🎨 Learning Photoshop on Photoshop Academy! Join me on this creative journey! #PhotoshopLearning`
  }

  const shareUrl = `https://photoshop-academy.com/profile/${user?.username}`

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(`${generateShareText()}\n\n${shareUrl}`)
      toast.success("Copied to clipboard!")
    } catch (error) {
      toast.error("Failed to copy to clipboard")
    }
  }

  const shareToSocial = (platform: string) => {
    const text = encodeURIComponent(generateShareText())
    const url = encodeURIComponent(shareUrl)

    let shareUrl_platform = ""
    switch (platform) {
      case "twitter":
        shareUrl_platform = `https://twitter.com/intent/tweet?text=${text}&url=${url}`
        break
      case "facebook":
        shareUrl_platform = `https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${text}`
        break
      case "linkedin":
        shareUrl_platform = `https://www.linkedin.com/sharing/share-offsite/?url=${url}&summary=${text}`
        break
    }

    if (shareUrl_platform) {
      window.open(shareUrl_platform, "_blank", "width=600,height=400")
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Share2 className="w-5 h-5" />
          Share Your Progress
        </CardTitle>
        <CardDescription>Let others know about your Photoshop learning journey!</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Preview */}
        <div className="bg-muted p-4 rounded-lg">
          <p className="text-sm">{generateShareText()}</p>
          <p className="text-xs text-muted-foreground mt-2">{shareUrl}</p>
        </div>

        {/* Share Buttons */}
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={copyToClipboard}>
            <Copy className="w-4 h-4 mr-2" />
            Copy Link
          </Button>
          <Button variant="outline" size="sm" onClick={() => shareToSocial("twitter")} className="text-blue-500">
            <Twitter className="w-4 h-4 mr-2" />
            Twitter
          </Button>
          <Button variant="outline" size="sm" onClick={() => shareToSocial("facebook")} className="text-blue-600">
            <Facebook className="w-4 h-4 mr-2" />
            Facebook
          </Button>
          <Button variant="outline" size="sm" onClick={() => shareToSocial("linkedin")} className="text-blue-700">
            <Linkedin className="w-4 h-4 mr-2" />
            LinkedIn
          </Button>
        </div>

        {/* Achievement/Milestone Display */}
        {achievement && (
          <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg">
            <span className="text-2xl">{achievement.icon}</span>
            <div>
              <h4 className="font-semibold">{achievement.title}</h4>
              <p className="text-sm text-muted-foreground">{achievement.description}</p>
            </div>
          </div>
        )}

        {milestone && (
          <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg">
            <Badge variant="secondary" className="text-lg px-3 py-1">
              {milestone.value}
            </Badge>
            <div>
              <h4 className="font-semibold">
                {milestone.type === "level" && "Level Up!"}
                {milestone.type === "streak" && "Learning Streak"}
                {milestone.type === "lessons" && "Lessons Completed"}
              </h4>
              <p className="text-sm text-muted-foreground">
                {milestone.type === "level" && "You've reached a new level!"}
                {milestone.type === "streak" && "Days of consistent learning"}
                {milestone.type === "lessons" && "Total lessons completed"}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
