"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, Circle, Lock, Play, Star, Layers, Palette, Crop, Wand2, ImageIcon, Type } from "lucide-react"
import { cn } from "@/lib/utils"
import Link from "next/link"

const courses = [
  {
    id: 1,
    title: "Photoshop Basics",
    description: "Master the fundamentals",
    icon: Layers,
    color: "bg-blue-500",
    progress: 85,
    lessons: [
      { id: 1, title: "Interface Overview", completed: true, locked: false },
      { id: 2, title: "Tools Panel", completed: true, locked: false },
      { id: 3, title: "Layers Basics", completed: true, locked: false },
      { id: 4, title: "File Management", completed: false, locked: false },
      { id: 5, title: "Basic Shortcuts", completed: false, locked: true },
    ],
  },
  {
    id: 2,
    title: "Selection Tools",
    description: "Perfect your selections",
    icon: Crop,
    color: "bg-green-500",
    progress: 60,
    lessons: [
      { id: 6, title: "Marquee Tools", completed: true, locked: false },
      { id: 7, title: "Lasso Tools", completed: true, locked: false },
      { id: 8, title: "Magic Wand", completed: false, locked: false },
      { id: 9, title: "Quick Selection", completed: false, locked: true },
      { id: 10, title: "Refine Edge", completed: false, locked: true },
    ],
  },
  {
    id: 3,
    title: "Color & Paint",
    description: "Work with colors and brushes",
    icon: Palette,
    color: "bg-purple-500",
    progress: 20,
    lessons: [
      { id: 11, title: "Color Theory", completed: true, locked: false },
      { id: 12, title: "Brush Tool", completed: false, locked: false },
      { id: 13, title: "Color Picker", completed: false, locked: true },
      { id: 14, title: "Gradients", completed: false, locked: true },
      { id: 15, title: "Paint Bucket", completed: false, locked: true },
    ],
  },
  {
    id: 4,
    title: "Text & Typography",
    description: "Create stunning text effects",
    icon: Type,
    color: "bg-orange-500",
    progress: 0,
    lessons: [
      { id: 16, title: "Text Tool Basics", completed: false, locked: false },
      { id: 17, title: "Character Panel", completed: false, locked: true },
      { id: 18, title: "Paragraph Panel", completed: false, locked: true },
      { id: 19, title: "Text Effects", completed: false, locked: true },
      { id: 20, title: "3D Text", completed: false, locked: true },
    ],
  },
  {
    id: 5,
    title: "Advanced Effects",
    description: "Filters and special effects",
    icon: Wand2,
    color: "bg-pink-500",
    progress: 0,
    lessons: [
      { id: 21, title: "Filter Gallery", completed: false, locked: true },
      { id: 22, title: "Blur Effects", completed: false, locked: true },
      { id: 23, title: "Distort Effects", completed: false, locked: true },
      { id: 24, title: "Artistic Filters", completed: false, locked: true },
      { id: 25, title: "Custom Filters", completed: false, locked: true },
    ],
  },
  {
    id: 6,
    title: "Photo Editing",
    description: "Professional photo retouching",
    icon: ImageIcon,
    color: "bg-teal-500",
    progress: 0,
    lessons: [
      { id: 26, title: "Color Correction", completed: false, locked: true },
      { id: 27, title: "Exposure Adjustment", completed: false, locked: true },
      { id: 28, title: "Spot Healing", completed: false, locked: true },
      { id: 29, title: "Clone Stamp", completed: false, locked: true },
      { id: 30, title: "Content-Aware Fill", completed: false, locked: true },
    ],
  },
]

export function CourseMap() {
  const [selectedCourse, setSelectedCourse] = useState<number | null>(null)

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="font-heading text-3xl font-bold text-gray-900">Unlock Your Creativity</h2>
        <p className="text-lg text-gray-600">Start Your Photoshop Journey!</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => {
          const Icon = course.icon
          const isLocked = course.progress === 0 && course.id > 1

          return (
            <Card
              key={course.id}
              className={cn(
                "cursor-pointer transition-all duration-200 hover:shadow-lg",
                selectedCourse === course.id && "ring-2 ring-cyan-500",
                isLocked && "opacity-60",
              )}
              onClick={() => !isLocked && setSelectedCourse(selectedCourse === course.id ? null : course.id)}
            >
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", course.color)}>
                      {isLocked ? <Lock className="w-6 h-6 text-white" /> : <Icon className="w-6 h-6 text-white" />}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-heading text-lg font-semibold">{course.title}</h3>
                      <p className="text-sm text-muted-foreground">{course.description}</p>
                    </div>
                  </div>

                  {!isLocked && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="text-muted-foreground">{course.progress}%</span>
                        </div>
                        <Progress value={course.progress} className="h-2" />
                      </div>

                      {selectedCourse === course.id && (
                        <div className="space-y-3 pt-4 border-t">
                          <h4 className="font-medium text-sm">Lessons</h4>
                          {course.lessons.map((lesson) => (
                            <div key={lesson.id} className="flex items-center gap-3">
                              {lesson.completed ? (
                                <CheckCircle className="w-5 h-5 text-green-500" />
                              ) : lesson.locked ? (
                                <Lock className="w-5 h-5 text-gray-400" />
                              ) : (
                                <Circle className="w-5 h-5 text-gray-400" />
                              )}
                              <span
                                className={cn(
                                  "text-sm flex-1",
                                  lesson.locked && "text-gray-400",
                                  lesson.completed && "text-green-700",
                                )}
                              >
                                {lesson.title}
                              </span>
                              {!lesson.locked && !lesson.completed && (
                                <Button size="sm" variant="outline" className="h-7 bg-transparent" asChild>
                                  <Link href={`/lesson/${lesson.id}`}>
                                    <Play className="w-3 h-3 mr-1" />
                                    Start
                                  </Link>
                                </Button>
                              )}
                              {lesson.completed && (
                                <Badge variant="secondary" className="text-xs">
                                  <Star className="w-3 h-3 mr-1" />
                                  Complete
                                </Badge>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}

                  {isLocked && (
                    <div className="text-center py-4">
                      <p className="text-sm text-muted-foreground">Complete previous courses to unlock</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
