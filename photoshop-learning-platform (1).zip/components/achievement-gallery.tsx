"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Star, Flame, Target, Zap, Award, Crown, Gem, Shield } from "lucide-react"
import { cn } from "@/lib/utils"

const achievements = {
  learning: [
    {
      id: 1,
      name: "First Steps",
      description: "Complete your first lesson",
      icon: Star,
      color: "bg-blue-500",
      xp: 25,
      unlocked: true,
      progress: 100,
      target: 1,
      rarity: "common",
    },
    {
      id: 2,
      name: "Lesson Master",
      description: "Complete 25 lessons",
      icon: Trophy,
      color: "bg-green-500",
      xp: 150,
      unlocked: true,
      progress: 100,
      target: 25,
      rarity: "uncommon",
    },
    {
      id: 3,
      name: "Knowledge Seeker",
      description: "Complete 50 lessons",
      icon: Award,
      color: "bg-purple-500",
      xp: 300,
      unlocked: false,
      progress: 52,
      target: 50,
      rarity: "rare",
    },
    {
      id: 4,
      name: "Photoshop Guru",
      description: "Complete 100 lessons",
      icon: Crown,
      color: "bg-yellow-500",
      xp: 500,
      unlocked: false,
      progress: 26,
      target: 100,
      rarity: "legendary",
    },
  ],
  streaks: [
    {
      id: 5,
      name: "Consistent Learner",
      description: "Maintain a 3-day streak",
      icon: Flame,
      color: "bg-orange-500",
      xp: 50,
      unlocked: true,
      progress: 100,
      target: 3,
      rarity: "common",
    },
    {
      id: 6,
      name: "Week Warrior",
      description: "Maintain a 7-day streak",
      icon: Shield,
      color: "bg-red-500",
      xp: 100,
      unlocked: true,
      progress: 100,
      target: 7,
      rarity: "uncommon",
    },
    {
      id: 7,
      name: "Dedication Master",
      description: "Maintain a 30-day streak",
      icon: Gem,
      color: "bg-pink-500",
      xp: 250,
      unlocked: false,
      progress: 23,
      target: 30,
      rarity: "rare",
    },
  ],
  skills: [
    {
      id: 8,
      name: "Selection Expert",
      description: "Master all selection tools",
      icon: Target,
      color: "bg-cyan-500",
      xp: 200,
      unlocked: false,
      progress: 80,
      target: 100,
      rarity: "uncommon",
    },
    {
      id: 9,
      name: "Layer Wizard",
      description: "Master all layer techniques",
      icon: Zap,
      color: "bg-indigo-500",
      xp: 200,
      unlocked: true,
      progress: 100,
      target: 100,
      rarity: "uncommon",
    },
    {
      id: 10,
      name: "Color Maestro",
      description: "Master all color and paint tools",
      icon: Star,
      color: "bg-violet-500",
      xp: 200,
      unlocked: false,
      progress: 45,
      target: 100,
      rarity: "uncommon",
    },
  ],
  special: [
    {
      id: 11,
      name: "Perfect Student",
      description: "Score 100% on 10 quizzes",
      icon: Crown,
      color: "bg-yellow-600",
      xp: 300,
      unlocked: false,
      progress: 8,
      target: 10,
      rarity: "rare",
    },
    {
      id: 12,
      name: "Speed Demon",
      description: "Complete 5 lessons in under 2 hours",
      icon: Zap,
      color: "bg-lime-500",
      xp: 150,
      unlocked: true,
      progress: 100,
      target: 5,
      rarity: "uncommon",
    },
  ],
}

const rarityColors = {
  common: "border-gray-300 bg-gray-50",
  uncommon: "border-green-300 bg-green-50",
  rare: "border-blue-300 bg-blue-50",
  epic: "border-purple-300 bg-purple-50",
  legendary: "border-yellow-300 bg-yellow-50",
}

const rarityBadges = {
  common: "bg-gray-100 text-gray-800",
  uncommon: "bg-green-100 text-green-800",
  rare: "bg-blue-100 text-blue-800",
  epic: "bg-purple-100 text-purple-800",
  legendary: "bg-yellow-100 text-yellow-800",
}

export function AchievementGallery() {
  const [selectedCategory, setSelectedCategory] = useState("learning")

  const renderAchievement = (achievement: any) => {
    const Icon = achievement.icon
    const isUnlocked = achievement.unlocked

    return (
      <Card
        key={achievement.id}
        className={cn(
          "transition-all duration-200 hover:shadow-lg",
          isUnlocked ? rarityColors[achievement.rarity as keyof typeof rarityColors] : "opacity-60 grayscale",
        )}
      >
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center",
                  isUnlocked ? achievement.color : "bg-gray-400",
                )}
              >
                <Icon className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-heading text-lg font-semibold">{achievement.name}</h3>
                  <Badge
                    className={cn("text-xs capitalize", rarityBadges[achievement.rarity as keyof typeof rarityBadges])}
                  >
                    {achievement.rarity}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{achievement.description}</p>
              </div>
            </div>

            {!isUnlocked && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span className="text-muted-foreground">
                    {achievement.progress}/{achievement.target}
                  </span>
                </div>
                <Progress value={(achievement.progress / achievement.target) * 100} className="h-2" />
              </div>
            )}

            <div className="flex items-center justify-between">
              <Badge variant="secondary" className="text-xs">
                +{achievement.xp} XP
              </Badge>
              {isUnlocked && (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200 text-xs">
                  <Trophy className="w-3 h-3 mr-1" />
                  Unlocked
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-xl">All Achievements</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="learning">Learning</TabsTrigger>
            <TabsTrigger value="streaks">Streaks</TabsTrigger>
            <TabsTrigger value="skills">Skills</TabsTrigger>
            <TabsTrigger value="special">Special</TabsTrigger>
          </TabsList>

          <TabsContent value="learning" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">{achievements.learning.map(renderAchievement)}</div>
          </TabsContent>

          <TabsContent value="streaks" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">{achievements.streaks.map(renderAchievement)}</div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">{achievements.skills.map(renderAchievement)}</div>
          </TabsContent>

          <TabsContent value="special" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">{achievements.special.map(renderAchievement)}</div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
