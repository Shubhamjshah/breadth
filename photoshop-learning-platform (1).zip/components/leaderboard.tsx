"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, Medal, Award } from "lucide-react"

const leaderboardData = [
  { rank: 1, name: "Alex Chen", xp: 2450, avatar: "/diverse-user-avatars.png", streak: 12 },
  { rank: 2, name: "Sarah Kim", xp: 2380, avatar: "/diverse-user-avatars.png", streak: 8 },
  { rank: 3, name: "You", xp: 1325, avatar: "/diverse-user-avatars.png", streak: 7, isCurrentUser: true },
  { rank: 4, name: "Mike Johnson", xp: 1280, avatar: "/diverse-user-avatars.png", streak: 5 },
  { rank: 5, name: "Emma Davis", xp: 1150, avatar: "/diverse-user-avatars.png", streak: 3 },
]

export function Leaderboard() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-heading text-lg flex items-center gap-2">
          <Trophy className="w-5 h-5 text-yellow-600" />
          Weekly Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {leaderboardData.map((user) => (
            <div
              key={user.rank}
              className={`flex items-center gap-3 p-3 rounded-lg ${
                user.isCurrentUser ? "bg-cyan-50 border border-cyan-200" : "bg-gray-50"
              }`}
            >
              <div className="flex items-center justify-center w-6 h-6">
                {user.rank === 1 && <Trophy className="w-5 h-5 text-yellow-500" />}
                {user.rank === 2 && <Medal className="w-5 h-5 text-gray-400" />}
                {user.rank === 3 && <Award className="w-5 h-5 text-orange-500" />}
                {user.rank > 3 && <span className="text-sm font-semibold text-muted-foreground">#{user.rank}</span>}
              </div>

              <Avatar className="w-8 h-8">
                <AvatarImage src={user.avatar || "/placeholder.svg"} />
                <AvatarFallback className="text-xs">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <p className={`text-sm font-medium ${user.isCurrentUser ? "text-cyan-900" : ""}`}>{user.name}</p>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{user.xp} XP</span>
                  <Badge variant="outline" className="text-xs">
                    {user.streak} day streak
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 p-3 bg-blue-50 rounded-lg text-center">
          <p className="text-sm text-blue-800">Complete more lessons to climb the leaderboard!</p>
        </div>
      </CardContent>
    </Card>
  )
}
